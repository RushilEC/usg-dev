/* ======================================================================
   Princeton USG — Squarespace edition
   Restyles every page of the Squarespace site. Content still comes from
   Squarespace (edit pages, events, forms, Instagram blocks as usual).
   Turn it off for a page view by adding ?skin=off to the URL.
   ====================================================================== */
const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const toast=m=>{const t=$("#toast");if(!t)return;t.textContent=m;t.classList.add("show");clearTimeout(t._h);t._h=setTimeout(()=>t.classList.remove("show"),3000)};
const LOGO="https://images.squarespace-cdn.com/content/v1/5a46a96aace86433f0ea985b/1582474088134-C299BJL8H6JV3NY6MNTV/image.png?format=500w";
const VIDEO={file:"/s/usg-reel.mp4",phone:"",youtube:"-mwSnAR-4JU",poster:"data:image/jpeg;base64,/9j/4AAQSkZJRgABAgAAAQABAAD//gAQTGF2YzYwLjMxLjEwMgD/2wBDAAgSEhUSFRgYGBgYGB0bHR4eHh0dHR0eHh4gICAmJiYgICAeHiAgJCQmJikqKScnJicqKi0tLTY2MzM/P0FNTV3/xACdAAABBQEBAQAAAAAAAAAAAAADBQAEAgEGBwgBAAMBAQEBAAAAAAAAAAAAAAABAgMEBQYQAAEDAgQDBQUFBwQCAgMBAQECABEhAwQxEkFhcVGBkRMFIsEy0aGx4VJC8BQjFYIzcpJT8UMGYqIWssIkk2M1NBEBAQEAAgEEAQMEAwEBAAAAAAERAiESUWExQQMTgXGhkSIyscFSQvH/wAARCAFoAoADASIAAhEAAxEA/9oADAMBAAIRAxEAPwDwgwTFYenh2OpFXdRKlSc3KVfo59tPiK0+9mQmYmjhDejac6ktAuWvEtBZQFKOkpUN0cfyHCuWloz0naQoHs5tUsG5dIHpJEnVqCFkDjI1AdC0u6rxLhkiBuBFORcJJRzbdzmzkEDKhyPwdqDAEGtdh1dAJdXeGEx2hvNnVkB0ckiuyQCa0dWt2bCSnUruDnlZxnZEQ5tuxiTDx6GuO3sdHYFnBTqkpEdKgD2tBHewI4tSOHgpi5bVq6EiOeoCOeTdy0oAemN5oaHqQYc6RPE5MbUrKCfUNugq5gwalArAKkjUVaYoBua04M0EF61AiwE0Uoq5CA01vTa9eNthZq+FuW7WoqKpKSkRx3LSGdCQpUEw4s2ZSK1rBXLqNYKQCYEnP7HXFYReGKQQqCPeihPDZy712z4PhJ1ApJ2oa9ZfZ+UH9Zhrti9C0pPpnNMjZz+Pbu/si3HlyVFJBBjizDQpfqJjr1cy/hrlm+bEerVA4zkRzfdYzyharltVoJCVBCVgfhMQVR0fRIm8pHa4D9OmwlFhYWE1NayerW35JgcPewfmAQQrTUagDpIIoej9dfQ46o27PW0qtuzbAq7NvWB5r51h8OhHi1TcUYAGSuJD82s2hdVpK02+Ksn6N58SfCEGkkmKV2l+YgTR435dPH4fQVu1cRhRbOi4oIgE+6ro/Mzjr2CKgjDpsFRrQ1jm/T8Am4jDWhc94J+W09jhY2/hEkWsSmdQkemR37PbWM/uR7OMSmwjF3RKlnQtQSKRl2NWNvD4kpvHw70+knMAHLlBfL4/zDCqw68PbSchpgQkEF8DhL921ci3J1U09WvLtXj16OgxZOBxlwYdOnUgAQJic4afYwuPvLBSLok+8SR9X1dm5du+aKUlAohIWF/hG/a/VG6e5/ZzV29+78KFXVm4oCK5qV0dLuKtLwXjKVpCk066vuh+YebY1WJum3ki2ogDqRSS+YNy4baUEnSCSkbV3eflhzh0lXMUu5IhKQrOAJ783JsIVcTGgrAEkjbthob6X9V+nshFk6VKHrV+d3hu3tv8TpRKUoUtN1ZtkJPInYNH8ImoKTvQuISSZLo0sVUCIqxOrU8MAq4AU6mlE+HSH1BCblpZA9RUI7KPmjMsATs8eujbDxkSYILoalgUePHrak2xb8W4lNAJqTkHKxmjxlaFBQ6jJitXzbSRAM0npyaa73rGWXdNt68cNGPW3rDY8etsDG3Z42ajbbb0Btttugbb140BNW7upWozAHJiAl2hxcDZ6O6dM+qex3HpOx7+8NrqrMGYq4IohKQNJg8zkeHVtabiwVATAqeGTomTGkyUj2Oy7+tIEQd+fUc3kRMUIozpHp1GYA+bn21p8MoKAST701AY7NCpJNCDG+TYJsVpPBqxP6YgR6qFUgEHIgVYbyQIGqYyFIEtNVn1b+SLF7wSuUGUH8PulNK9x6N2sOVglSglIrn6o6pBzHa0kJBIrHEvo4tWLer+brSUlMUQZp6pzHJlBLuqs6vQkgAdcz83NPrCvDUDCdRGVIrB3j2OHbsi4KSTB5ZblqRsJ05kGNqyetax1edzrSc8oQYMjm6Ocu0tI1KI76uCYes7Nedv9WvIuW/AuIJUVEjSNMjIwSZFRlR8/EZZM6JEwYG5+jVNPK/TVStQGk1mnbWnR5pBAhQ2A2z/ANfkw29OqV5VMJzJ51AA34OVbSE6qpUPuklKs9hmerjEJXhhGIFohQCTXZWVe3gM2e8dNkBK0iR6oTpUpM011kn2NPVpJuKBNctZnUBG+cnm0tRZQDDuREcXqRWralFWbtS1tOpQHXLm9uDSogiHZFFJUDEGXW6orWVHdz9kC5VpQSsE5TVxHPTblIVIiYPBluBa+balzbEJ6dH2nkN4oxBtZhaSeRG74I0L6qzikYJXiWkzcWiqVe6iehGfyb49Yzvw9Zxdm3cv4UqSCQtXySSO4h9A+FweKXjjhiY1INxVyKAUgR3vuSQBJIA6mgfY4zeMKbttZhK0KOcBQJ+TjXcTasrQhSvUsgBIqa7noGiTnrJk4YvWlGBcQT01Cfq2Eht2bYSr1pWIxlrDEJXrkiRpSVfRpR82sbIvH+D7WKyupKQoQQCOhq4icPYQdQtoB66Q0/D4+3iV6EouppMqTA+pa+wY5vFeZYfDJnVrVslNfnkH59isda8yCUFJsqB9KyZFdj0cjHeT3QsrsDWkmdO6fsaUPKsSUUtKnueNtn1rTI5u/YuWVlKwQR8+I6v0/wDRosYYYmzaPi6E0k5nMgPp8FbWLCbd/QpaREUJA2BfN43AXwonDrWQZOjUacq/J6f6/Bbrh8DjLiMWbiySVnSo9Ox+0KxKbYJugojc+6eRfl3ky7QXes30VVX1DcZjm1Xze544RZtV0GteGXY3vqdnfo5/EYOyi6by1XBZuK1JKQFagaxM0Y8ZGKShSLfhotjSninZ7h8UbFvwMQjVaJkA5p5NDum5iLq1ISSBsMkp+Dzt2dfa8z5+ifcAFA4rWr+DuWEJWooOrooEjm0Z8+WfLadqPHZ62oW2nUqK9jkBJTIBKSTA2nt2cKelGQ3FK94yepzdGKNVpVCOyr668MOkC4m2ZKSV134fV8K+qwNyArXVCUmppB4deTcRXLHN0apdu21+7bCd3A9PFiwW3aWRJFZHJowHjIYdGzY2222a4h46urCXbbesDHj14wNdW22Gx47PHcNj1t6y0G6uzxqBoJSZFC5+oqTVM8Q05qKClKTJMnKGciQS2GRUF1aAiVFBlJhmOlSpyn6uMCBtLIEGNQj29zkNg1IydNRBBByybKqyKOs50aJYmat5u6V6QQKg5h0CiMmiaEktTt3fDStCqahERIPP2NIBL0knNmGNrI90xMjvZFXCREnNwnreGU7d1Wk2yo6SOfZ2slmwLupJ9KolJnpUz2NJahZu6NQKUqBBjUJgxQj8w5qVFW1IE6geR/J+TAfSdw1+xp8MFd21AkeEpJkgnqO+JDSL2kr9AAG0GR8697ACkkdelM3M8VMkhJCiDO9TzrDThWWUp0nevUNgsRaVbSFrUiOokxGwG09S0VUAwDPFyV3SpCUnJEx2uC5hHLsKujKl2YqwEn0mRyhiJl1LbRDapTECm+7qHR65CUgJUoAqgdWs/pTcuXSn+XbqVbQMhzLQCmIyq1Kzf8O3dQSYWmNPEGh4Q4y34pFjBYxeHupCQAlSkpNJpO3e7+aYm5dxK7ZWSlB0gD3aCtHzS9KSNCtQ5QXhXrXqVKpMnqe11ElPB4r9HeFwCYChHWR8WA3VrKrilErKgZ3cFCDcWEiBJ3MAcy+swWGwwUVYm6mEkjQJIUR/2FIenyhL8x8xXfRatAkehKlwfeURkeT5jCg/qLUCTrTTtawvCLxFxVxKrIStRI/aJECaCJc2yj9JcJQpNxYBGoCUp5TmeOTOXLO78J+nt7x/PV5dyZ1qnrJfXeXeaXCrw7qtUiEE+3clvjznJn4l/wAxg3EwagQWgBJ6tYxdzUtKdWuKmkV6OFAdVvx+CxgUqCiqhHukc932b5TDnw7F9YFRHzYLeIQi2nT6VGaqrJ6RsyX5Ln9OvWoW0qUckgk9j8aV5jiitV1KyAVTp2jp3P0nxiuyvVpJVKUp4xu+KHl9/SE6I7oeP5OXKZ4y3tjC9jMJ+qtJxNklFzSFUJGoRlzDS/LfM1quixe9RVRK96bF9/at+DZQiZ0iGjHy2z+oRfT6SkyRsT1fT30TkLttOH82C1AwsakxuqKhx8RoUswkDfgfi+s83slVlN5Hv2SFjluHxyrCryk3k6Tbu5V3Ik8npZ5QaTsRF9Ej1FFJGUQ4uHqkpkp1Z1gGOr6JV79Pc0oiLiUqI0hR1cfzu+dxUoQvSvVqKVKjrJz5HZ58uHXVyw5y/q5lcAkAzxceXjb58dbHjkLTARxE/MuO2GNs4RKSejEw2NQtlSx4ezT3fJhMUmCxsjxhqPGSHRgVbevXRqNuzbAx1d22BR68etqY29bYTG222Gbx62wMetvGza8bbYDbdjGzqwG7N0elomASQOrnqSLJiZPUNPe5tBubo9ethtI4uj1tgWDq7vGiUdnjs2bG3rxoNdg6vWEsQ1dS7ayn0m2NIkcQKkTkD0q4mlaxRJMCTAy5sti34qwjUlOqkqyA57PNAC7ZFax1+PFxGs4u2bS9BXrIoTyy3NIho7cNRkDqyBsKkEZvQ5JulSdJgxkdx27uMGgMpOnNia4tYxCEICTrFBWkDnQNKVAhMVBOozM+xxCCeOYFhOQ76s12yU6VAhWsTQVHMNb2Ca1Jf8tJGmtKDo4QQo5Asxuao9IEdJdX6BcwF1OGua7optIBM8A+5t4jB4mUaaE0oEwTntD8rMriVZCn1ZrK021SrUQPwik82Tq7/wDiL29Av+VBCikLOkiRImvZWHCt2DhyQTMdHZHnA1JKkFMUCs4DXSvxPVKfVWaVlx+ThOfGydVHZMuW0X7cwQeAntd8H5UApNy5cASKgZKkZcnKCkoEavm7eOgby64fjnD1/wCiol7DEXVXAQdRyBmHmhf3SyjE2d6NbtLsL/GA+kSo9of/AI2JBGyXzVuzbCgSgUIff/p9furB7XVeCV90F5/u32+jl/DTqKbXug6qzKukGZo+vseKQVXKE5J2HY0JWGKIgKRBBnPIzHa+jF9B4c3tHLUjfk7uod3SFCAoEHIiH4+m3bw167h76lBKT4lsA5joOhfsr8/87wyVoRf3tmo6o37s3UocXjbFw3E3AKXPdSDKqDcbNOvhKLASlC0lR1KKsjEw6p1rxCQlRUCYCuHsfWrwaoVcNUoFOh00qD1bv/0e5jytzrOHu3zCEKV1gZOlyJo/oLy0oOEtKTHu1gRUdXyce29uPHPMsOMOqzb3FofUvlH6H50UXsUkpUDFsClayaF8b4RFTp73pyXx+CjhUSi5qFPsLRSmgLW7S4BgSRU9I3PWmziQnTxBpWkcQ8229EqCHZSTm1C6TMGNsoj5MfiQgo0gzuduTSCe7B30sZYS6jPc4zuMm4Yaj2DEvXPtISo+pUAVj70CYnIcHU7JBAn85usOYq4TCZkJ93hLhloJOo6NJNAZA+xxnfXIg5cPz3sYBM8OLpSpeNbw9i0ut26Ej8wTwabcCQtQQdSQTB6jq39Fv0jvHZ1cqNtttgN68bbNjb14wG29dWARIBIDo8djtxbNj1t2DSWO4DxsuSZRjZAJdG1Mbbeugb11etBrJMZUdG2iVbbetm13TmHRlBhokvxrqNQCiArOMjzYkrIyp1483GLxySWrUSSoyTWc2PS7pEhmoIl5oRSIY2RRksbs2tsiaHKXJupSFenKAWzBB0n6x0Z129ICx7iidPWnUM1m0Lihq917ftJtxCiRsOjWFqFychF25bMjlBEjkwoVpOUtSuJCxqHc5IqW8UhSVi7vBgD5ZUaJcFuBoSR1kzLoLc5kB30kDOWdkjhM8HLUicocaaZPaxIchXQehav4xTQU4MKL5RQwR0LgFT04y73J7JKvjlj8YtN1Mep9ScK3iHq5yLxG75yWwtssegoxak5F9ph/NTACq834kLjkJvkOclG2Ppa3jLNwVI7WdVi1dEiH88oxR6vobPmFxGSi8/Fp5eseoKw1y1VJo+Lv+d27UpSnxFDpRLJc83veAsJAKikgHpO78yw+CvYlQFEg5qVT7WdxOca6H99YxZ9IQkdAmfq16zd/W3kDEBVtUe6QQhYIiU9C1Cz/AMfSiFePrIgwBA+pfQLFu1K76fdHvEbBvjfdHLj7PLcPhx+qVZ1QUGbZAzTtPJ+jDCXLh/aqBGkpMdve/IcR5gu5iE3bYCPDPpgbceb9hweJHmGH1pUpChQ8Fe0PfyZ3jfl4NiLFyxeVaUDINKZjYh+7eU2F2MGhKxBMqjpOz5rE47EYK9+2sWlmITcAiR8+598lQXbFxSxBEzkmHlirbceB+ZYf9JiVoSZB9QP9W3Y0VOovqvN7ti9idVlQUNABO0gn2PkdZDnlY6ePwlALk50z2YkpBOZDMm+QfVUHve3FIIGnu6PLWmqnUqkyBydVk0kDLZxASGfUTk2kGWZKhuY4xLjh2NC5hGRqbTMwXgq8ygu1rEVZ7lrQkHUDOzjSSXIKdQpV43qztBOd2Qpij0JkPQ1EpKjpGZaqmyjSZXCgcooaTn8ml5Gci6yXe/uVaZSehD1atRkxXoIYnubkMbdoewxSjx2dWwq9besUq27PGwuBSWNt4wJgT94hPN1ugAIjKDHexISVKCaVpVqivcSkRKZSZG5OzQIzIDs14YNS1hJC0mAVSkCOVatIuJVaXCkqSQdxBPGrowhVkLpQK4H6O56OKixXJidoLxgY22yQwBQ2yEOjYY5CQk+8SOQn2sL1hsbeshTJoQfsaIJ3HKXRmSYNajcMBkiAIMh4QNmtXgFptkJRUVM9NiODresISAYKSQDQyOTy8i0jxHVkUrKswGNUA0JI4sLs0tNRuTv0HaxNzAzZkwXWJEQncu+kbl4TDjEt+KSklemjCs6iJcKW5egKRQEaSd6uirk7UYtciD2MMh8s0hCBsXQEh7DGW4YktlR2YwWXMF3eqAnSXVt7heXV48YYjq9etpZLvLG6sCXqcpNwhprs2nHRpvENQRiCD0fJAuSFukY9Es466k5lzcf5gu7g1oMHVAnhL8/So9XJuKKrakvOw3OJ3h9P5dibuC1XRBQSErT9FdjQLVpd1QSkS/SFYZNq0EJGoFFeZzk9HlKq1bzHzKxdQlJQLikqCh93tfA38Zdv0nSn7iSQmnBp90G0o21fhMOltSQoFQ1AZjqy2n4gvGZaklRIGkdOjFIeSxigKTKZ4/6uNDkypI9KgAdpcUHq2oaYbMZhjMbMbrQIl5LxsCXJNo7EukQ8h0aZbtqu6o/CkqPIc3Msm7bSVpAgU1EAgE82lAsviKCSgH0kzHF30mmtWpUms8IcWasmukcZnfvzYh1iXKoJmxvXkNGbsA9dZYDiHZ4M6u5jZomhWxEsLs8YFXj1t2bG3rxhqtuz1sDrQpOkke85Fm6oKqAuRAB/NDxci/bJuekZ1SAqac5PY01SVo0yCOjFOtBt4i2VEJteHAkKJUesTStYq0rEXUXE6dS1wr0LUKkEVB4zl1Yk2jdACSkJ94gmNM0J7Ds0eSk0OTWJEIpmOHWHftFQM/Y4vJrVpaBaVqTNeg75NRls2YVq4udAUQJyERO2brfifc0K36HiBtyYLdtV1WlAk50ygcS7hClmJyB7AHBIbtMOUAiQDXjMdgoXEU2S2oM9vRXWdqc/zm4Qq5CFAEk9Kc28PAi9h1Mu4MZ5MCzupOnerLGkggg8iyLQIBiJ/NRs8yQwB0PY5SgnQCBQyMwTI4ZjtcZQKY9jopRVGVBFBFA6+Qn2kG7I9Z0pJASkq+mQZLiwmEghQgGZJjUKjm5OD9B1HWqhhKCpMxFSRFA4d1VuToRprMTq+ebQJ7xlVUkiu+UfJgdBdnSwllD1Q0sbI8hhKNvHjDXePW2BskOru7FgCbdnRgN49bYbG23rCa7Mbs2DLbs9YTIbZnWGJVdw8esCUhUGWrBRU0MNSQYIbS6HDKCKAQ+luhS7MpzSQfm+PQay+4sr1IAyP5h5M64nFK8ZAthCSfvRXtL4yCihD9Bu4vxNKFICVJUZUKZ50aPdNsEhIpOZrAO5c27W3H4cq6uTcUFLJTltycZw0Xg5usOwexVgCydWd5DZhN5MtBxYmzWBZ8nGdpYRvId3ctEHppLYPpht1dabcmoJRKaCZaW1JN9YAQmBs8uW/QRFDSYLEyqBBM5urqEE9etuzVBdixttm0OzGXjZ4JLbo20MWbl1bDZ4n69UAAJj65Tm1vDquIJ0BICUeskAwYz1bTtBzfKxDU8OpIKkqXpCgM5gwcjHVgTbqLWqEXPECxqnKCes/NoiQNWbupfqJTQZDllxzY5nn9WGIpJzgx12Zbfq9ORVv0Ark45JiKuahOqzcVSQRnE/HuaJ11pKSBpnUhIygFfFIFDTKc3zeI0JWoAKBBgiieOVYca3eSCkKSSEmaKiJ6dBNXW6tSlaoInIzqkc93OEgz0oyKGVI49WJzFe4N+OZ7tg7NDybES5Kl6gkED0iObjMA6VBOaQodDP1EFyU6FAgpUK5g0HCo9riDSJkE0pWI+Tm2xIKc+AoSTk4JIUNEJ0yM9WmacC3cRpAIBiIqd/pDkBUJ0KkEiuwIjtq04pBJ0mRTjE9Xl/T/tKMEiRv1YVe8aRyazoF24lKFDUroIE9GS9hkYco1FVyZ1iCiCNhOb0lNARc0gAgnPJUZ8RxcE5l3VEnSCBxMlidBeXjq7BsL7srGyvRmb16HaGBHIdXJhihhqvW3rDa9Y22EI6F1d4YFG3dtgDbZXVgUbdnjDWdoY2RtKwdg65urELtvYbYpoaimGltQQxFKQfXYdVB1fLiC12yZIDipJWItxdVCgDNBuR9jQ72kJpNTvuIfVYq0s3k6QJKazwacbSE2tarnqkwIzjoS1mrlca2RDVbmn0nhWBk041ebUByqFPFih2mGA43bMt6tL01Z8GjOwdtLqwmNvXdgUbew9gxLDY8ettEG5FqPETPViex9jfybpblhMkqMB80tWo0yGTIpa10UouNk8uHGz5uiRdt0dXueNdXrIBIOcjuh0oJnCRs7oR4k50GwJbiAaUc6Fjb0ioI/O3VjFsqPQPUmkEkDP/AEYZjJhMLxt46NeqiJPe6KEEjo2ZydW1MevXaYbAtDma9di80k1oeRDE20Qug705siV6ae8npt2dDxcZ4wJmgLqgz/1NFD49nc4+XBjcrxF5EyOIB+rRAO4lk1cEjs+MsRMtEq5FuCqpiN6/KGAcW5YEsKJmaz1Pzruz3LiZOiACB1cAnjLo1hFmypATAMXCoQo0CQNwrbixXrqrtwnUbhqnUrpsQNi0xsiGBUttw22Ym28/KHjb0sJYMzGGV6JYzhiDuC0Gur10LYVePC6tGbo9ZAGGoGV2bYSrx3d9LQBdZcnS80sCO9dtMOrDVh47PGyXDLDjORLaKs7wxyygtpChzEseb0BgKoo1i0rJ8+C5yCRk5qS3jVHwRc6KinF8ou5rCSVTAFI6fV9mpOvC3U7xq7qvzUqKnM1UTV3PEpQJmcsuvFxiEpMAyxFJEEiJq76dVQ02VeGC9gpmRLGA0DArTbdlOonNsJJMGjO6NSoPUMChBcwbdrArbk1YVAAZc3jzJxmliajDquKSkEAnKTA7y4ty2q0opMHkZHYzhZKkzWH22GwR/nSLgSJ0iDX7oDc3Ozecirtm+juYcXtSkpNtWr3QKAdZyfO3EqtmFRzG7eDGEQ8FSHJtjxEq90aRJO52p1a5+lsaUEXPVGopzo0WK2cGANV1QCVTCh6h8t3Hu2UoEk5zEZ8J5vskW9OFtRRINQfx16fnJoV9ErUBAB6D6NKcargxl9ZiPLvAsm6LmqD9S+Sl2DDX0FKEqIlSvxCIiu5aKkE5NXIuW06vEg9N49rx594ZV1+BZRckJUfwiJKd+Pe+bXe8RRJEA7DpLirUVGTVhZx4Z39hJWrUqQIEQBnAcdtt7hjx3LG2Y5rWAGBttga7OrIGGq9bzeMJrcRFfsePWiY9evIYGPQ22wLOrb1omO7q5Wgx13gNECKGong9Lo9YGO6on0zHHN0ZNJzIIHWCwBOzzk7Ogs7urs6NrIHV3aCzqRDsymraUV1ZCxsDQyNh7DDVzdwIdZckWLik6yCE19RFKdHIAl3AUcnJtFBkRWDCjXIdIcVeIJGZB4UDjQMLdw7HuLOLJ3p3tCKiTMlnTeuJyWrvkdxd9q69C14J2LiKQU5iGVGKH4x/En2p+ENbNUg0UlWRzB+BefcV05Uphic9XpMbOMpMPRj8AQ27PHRnLsxPW0pQLPLhBy0liR0tXslpqc2qW4mWg6Owqug7yO9+d3Ei0pafuqh93bMrD5PzFEX9X3wD25FqdlPlDJNwRB7WI0o2Lg0BMV6vNRIcY2WEKmTEMYSJZE7y6y7xS0HN0Lsp0emYhcZDhLHWIbHu9ro6GrutW3kl5LLGA0/qbesApms5ZP0BSALv7FfgpitKcO9+b4ZdtF5CroJQDUD89X1t3H3L6imwEpQExEVPe4JJHip1ELSfwwAPUo9By7GkYDCoxt26LtCJkSJFch8QyWb1rDqBtpUV11bRA4tJ8XTN22tVq6cooI3DQQ8ZhlYHEFE6hmk9Unq+nwRQmLpIAgzvTcPn7lw4pABMrEmTmaZS4mEuBK9Kp0n5FlN3i9F22sSE+HVOnIT8d2gglKhM5HiXGTfNu6VAiJgAjMcsnKN9KjqnTFaB5pcutVxWoalFI60Hc4SE61JTMSQJ6Pol3ErQs7mQ+fRRQPR6Q3e27WFw8nWoqjcSB/q+dvoPqI9c7iaB3F3SkmffFa/UOAvEXF+kLIG+2rm8pO97BJdWQ0dHuarIHR2bNjb0vGibk6PXVs1naXVkpNWjDeu7owjePXjYXBePQHVhLPXmbcOSN62BL2m0sDGpWlkV1CJiB7w4gU+rTnJQiR+LVmKUc0FQqtm2sBJmAZOntyrnt0aOPUQAMz9XLsKHiolCVAqEpUJHHcPub+DwVrWnULa1JBQSdSDPSJjLfq5+CANm1hEKWQFhadOkoqFCsZxI6ieLtZxtm3hxrQVqASlKRXTE+sT6YPTN8mu74gQnSskwmtaig0DamczLAq+vxFLAAORpTu2azSL3mXgfszbzIk+lI743l8kyKWbh1GpLE749RSzs6Oz0Uu7OoesAwckOKGUSxNbDCQ5ZSS4hoatpWYyWyWr4eyFJUtStMChLi3CGw2HSqVKUNSSP2ddShw2732NxVxdhdsouEJSaQmgjOBI5wX54vEqMaYRA/DSeZzq+jw1+14RT4ikKgiFSQJ6cJ7Q+XlLew5i4EIQkpXU+8mMuR3BaW9Lq+yTFG9ePWzbDXMHd8MqCpKCKjjsRxaG1azrI0W/eJqKVArmWqRfxVhOgLQZD5sVo+lw6klK0GQgmBOYPZxaHetm2qrzgqHDG5JqGF6M4C7PXjamsyWBlbSUQXLBachqIaL4Llgy4nmaP2dtfQkd9XIt0o1LE2vEwlzgNXc5nVTry8OWlxA5IIetdMH6sTuAVZfUMBaNOCQRLhbbu6VGnB4FKTSnyL01nisUdIcvxFU+AdyhJqVjsc6eIQdmY2zNKsUdXFU1FVChLW0WZWkBQABEqNAidi0m0vwlhcTHc1y3fBtqCkBQPYesyOh+TyJdeEugquLEiDUCh2kR0aUsxQxtUbU6NSXiruhIQqAmdXTgIOzWF4hAs2/DRZBCQVGJUTOWTNKxyltaEKIiRtOf5lpt2i5FJrTZyVKlc0EyaZVYbkaQdxn9jX2a+oFOo1PtcfXVgDtzbwLymDnw5uqMwwPXRpdyiqSKCQXF3bJl0YBVHVwYmbTAHFhYbW3po8YSrsBLYE5PGzVeNttmsySIiBzY22gsXjbxgNtnSBu7KABpVzqWJWIIUCaHTGx68mB2qGYJpJBAOSjMfa2YVHVyCKn89zwEGJDCCLsIg0rsejsqJoxMMZOnUNUxvGccGZNwg0qJ3cNtySXchKyUnuNOw9GS1eCCrUhNyU6RqJ9PEcWnNthM1LOozJ458w1LwUeCVquEKiQIkKVNRLgWlwFIJgLisSQQZ/wBXM/VLTh/AhEaidUevlPRzSJpGmnTo6MjG7BskMTMGKWd4ehyAWExKWr20Bp6S5yVAFiaU/BTsXzOJRoudgL622Qphx2H1IFxNdOfI79jGbk7SPEVD7GyhWlVq5bT6pIMmaUicoaNgrY/UICpNCYTE5cX3V2xrOqCSmmmculQXw/m5WXPiHrgrmFR4OtBhQJlNVGBx6dkPmgojIv0HFBdsqNtK7a4+7OrqARI+j87ev4rbLt3tbG2231m149bYGuZa9BC4J7YYwibZXIoQNO/NqFu7cSJSBX08waUHWmebROjtXU3fEGiSUkzkMvY4t1JXZr71s6VNU8tUFhQ0jI7VkiKkvLg8O6Eqyupg8xv07nibig8Z7iNCiOLCXozCLq7OrsxHobh2hgSQ5iC4gDkxDCLqFbPq7QC0FPP5h8TZL67CqAJ4vOsuTybTpUoHYkdzMADRqWJtf/kXRxnvactOiHprsnxplNNVecUYZJcxI1xxc/wAG9VmkUAluIav4SeL3wkudV4kiRs8hrPgpdfCDen4k7UsfiPe6HOpal4Y3Y120gZNanxRgJ+0tb8FWhJ0KEgVGT55JrVqybSlgZ1yr82FIjkKVcUj3c8+DupBzUYEbNwQoySSCazuGYYheRgjiJeViLMJIia7MhGpOw5buXcCTJSIBcWCNO0sSh6CGAtQIiPV3MybZu5dhdaCO9hrP6a4SUi2ZBgmaS5Jt6UhC1iEzQDc9S4vKT3Nz81l4WUp9Riu7FBegVlsZ1bew2DVE0dG2dUbMMISHhePc2wZo6uzqwLPXjv14MNR427U6sJss6akAOM5opCg0R3ElJHyeFS1ACVKCcpJIE9Bs9WSo1dIIJEjsObkMNtQAOzEY2cjWqs1YM2wYnpLcUZMgGTUOne0ER45OknZ00+kmRQ5btgF68zq7NhoMmS7ZmXjko06TOe3ByQZYmc5MDoRju6tsUOyhx2VhJQZ3GSXIYVTkKIfWWL2x7XxoLUEK0ljMW/b/TXkrt5TKOHVB9nBq1zEqIKyNQIhNPcPMEVB4VDi3ovWik5xI5h8naxC7e8jcZ9/Vlk5zL8+qLL8x2qMVQglCZAkmtfrB3h+ZqMkniX0VxCcRBSoIIGX4Ow7drQ7ltdowpJH0PI5F5cPxfp77rl1HbeNvdo1lSrTsDwOTC9YGuYnoZ0nJxM30iD4iQlfpj3VAUECk8GiKmESQtaUrCSQIIFOKTMRPEPPMLhm2k0UkSeGQ9lGmjFmyFaTKiRUe6I+18+tariitRJJzJeedmV7pCxq72nAu9uTR0IguirHRmdC6SuCzhwmdJbIph3YAXI4sQlpo+hsZh8wDV9DYNXNRSNjRpxM9Uhoa6gvo/MP5iDwL5jOebHdx/1g9kDU1eZMcGmWxCpcmZLG0QSuFQ6lZ1Q8UPXLCffl1kY7f6lS5RALg6zplmVVNGDSdJDMirbottWqrMcnFtjTQspOzlpPhS0EqV6vyWvLTHgmNgJ4gtDQMw+gUqbdkbzPeWqriRliVqH/AGP1cdaQmKzyLnrtq1rocy4ygpAJA26NM+SBINDLjmZpk2VE51dJLbmZL7O1cRbQkXBpNCNJpB9ozfEBzJkCvB58uM5GV1YshepOW46nq4JvlaiVAGdsgwFISCzYe0i4SFa/dMFKSYUMpgHPJk4cfQM8VSCYMUhwdRZgitafWXJWLQoQftb6hE0pPHg8kih22cvId9XGmObe0zJ1HIDlRjNHoq6F2ar147gOlHLoy7QxNEs7sb1hm8ZQNXB30KrwmexpIDmoVlSeDhOZbSZBGbDOIVEcXVVTxc+4moVkXS2jUXKUZG+rena7kEElqSxAJgVPa4ZB6snYVuEKFA4Uxk1W0RbXJkgggx/2Hc4tsQuokfFsIyiZqCO90NWe6DqMnV7HSBqESfk0YJgBjzZlB3MJMpMjrk2QTulvVJ6uUIiadI9rQALEzMbZxVt622pZlYXdhDguWC4QcgMSlghyQpp72WILSVAvlC1LVDTmKUkjJzk4hQGlXqHQ1Hdt2OLpdgnpV3uDNFKLa/cOk/dVl2H497gqQpBhQhnISnPuH5h08Q0oCBkHO+ys91AhR27WfQkZknkPafg5ovJVQqUj5j5VZvAK6oWlf1c7fReT1JuoJ91IHE1PzYVKUrMkuYqzdT+FxvUNm9GI0MyBJbqWqWbJOdGJWQnSwrG7mlJSYLCoUeTKoLE7ur1INt3eOlJiTLkpLT0uaGEUAQ1qydmhoDVbedCxz1XzKnhnm+U1FU0fW4/1BHP2PnQJFHDu/H3xVSVIzD3xK1DOoFMVl4ASqSG9bZUArJYpLXYAegcGanx9yNqo6alNbkcHtBszVePuREqMyQWXUo7NTMOFBDNGe69kGSSYoeLW5tqtJSVAKB/PFolr0Vz5vqLVtBQCd9tINXFraQhLvnUQDThk01S1Vr8C5F+fEVSGnKBzLI47PlGLE7mSJ2mGJ6ILw8NAGRlxV+GRIoZoPi04MkCBGbnCSFXCoZbfkvrfL/M/0QTCNXWFaZrvQvm9KANzIypn8HCC1AACKGcmAs4y9+oxK7wTp1mSmZgxXYc2jq0EcZP57WJSjcUTuotS/TFJ6ltRPCaVdIlqlE0NHAXwcqz3VT7HSlZdMmRCgkyQDz2YgRKdWQ+x6pITxbNynpo6DXcnM9WuwivHj16Ka9beMNYGGZK9LjNtYlZqtvNLSXICy2ZZWNTrbGknk4NXtXnqsKiqiHH0cXDq3BZp4llA6syPSTXZp0FuGvIYlKSK5VLh6IMy9hiMhmliMTJLx429ENchBqA4rKn3hzDCH2dGXZ1aATbs6sWbIHjvMNpFhlYg7MSu9l2AYywwTJZUph4gTVqQTpTqNSfdHtPD6uTQyAkSsx0G55cOLgKulVB6R0HtO7awokk1JYdJbMNt627Sx6DDbbAVEYq6mmrUP+1fnm1ROKtq9+3HEVHxfLtUwqzbXIGqhkdRu5xW2OpTZTcTrRUMwRD3A3EpGlJKSQZKsgo7Dsni5WIui2lJSCrqqInk8a0nImXRk01SaNVkXU6kmQM+o5jZhUmjllflzKqF1cq4HHFQ9ozR3Z2IY3ZiswLBs7gtip6VVa3aIKs3z4atZzYxqbjapTzaGhrWL9wf1NEQXnXb+L/WJChky5sUFW7vLTpVKkoEkx9S4Rvk+6ntLAUlSiYmvc5Qsakatda02o10yvLELxbs7MvjDJSdPEOyLJUmSoADLeebAUKQdKhEuuinL3TQoHeXctPQnTcI4OfsxqKkUfRWklSExop94n2PnoKc30lpaCiNCZ5POtuLnMQIury/IaGqc2t3q3Vdn0acuYL0jm5xLF8DDrtG2gyE+r8QM5hoSSJq6F0duVOtrAUcgCN3ilJjeXFMOjQSwox1YHqTBrlu7GpniwxLfvJ5hri70jp0hoKaEc2tXNC0FQOUOaVJCipebKQCBSo3bSWyWNsmIZDoQBu2WN2zSLaQqZMNWtoAQoamg5OQLhAhzhBEQ6sysmF0sQBickZMUUYQbbbbCNlTmGJnRmGAsaXuli8Tg98Tg88WLpegVY/E4N+LyZgFIdYYfF5PNZ4MwaM4qxR21uOVN4SC29bdoVdhm28YSdsebGz7HsYHIUevW2LN1dg7tkslnhjDKGEPswKoHOFXGXVUMSmWLYVU+6mp49B2vVqlRJerKkAITSM+KvsycIaiay5aQQwwkTuyQeLue1oE5VvoQ4UNZCT0Pc6LROztJIbdyCHWHSWM6CQaR2sUObZt6yapGkajq3EjLqwOow1olYUc9gYoOA6/R9Ou1qw1xRyAkDPP5NLs2llSNFxBSFGQKZ7A5tTC/TdShUp9Sc6AxQV4vm5VfH5eepuGwpSk+9PNJTuCH2EJuoStNAaEbpV0Ps4PkLtlYWRw1RM06ubg73h3NJ9xcA8Dsez6PS/BKXE5tLTmQ+rxVuFF8qqinMRVSwFyCwF7FGh68D1jROQWsW6RxaAkNXt7NsLE7F/ykc2kW6tXxf8AKR/V7GioUpNYyeddf4vgo5OJuGtXTdv2BeKZ0K0KVGxFJhptlKblxIVITmqM4GcTu549unlcYlKk21qKfSox06vLZKz6RCRs/QMJ5anEeODrRbIGhUgkK3mkHi/O79q5h73g56DpJG9c2ePdcly3r0HvnSdIjsaWpRVpnYh91g7K71m5ZieGkav6pNYBfn9xKrN1VpYIUlUGeDmenou8fHF/93sc1IBDV7WEWq3du6gEW7ZUf6thHUvjAtUzL0srq4f5fHfZTtq/aKTJVO54PsbNzQgZxwEvlhdNtGQNZNOx9DavoCaIWeReV7ehz/Dfxe/Uv8b9EW8qbyz16iNnDWfSy3yDcJSFCdlZuCdRe0eXfsnxV2SILPoM7ZN6DwenTmytCBu6qCZAhlhXUOOqdQcLuKqEMbklCzsa8GApKTBEEGoLpmYcgMAZvV1DSo1XpEw42ssqyYguIxadpBIY1oAydgcnYtFUKGQJZ5eVdIR1MTKvZiaNJ/D2O2wdPwuuTRBmjq5QqGJQhgCey8bbJICjLkS4IZ+xgSZeguMaZh5NcnJpk8nQliV6dmPVwYA5dHpzdXSGttvGA2222Aqp9yeX0cdyUfy+0fRxy4Cjb11bNrsHRkDYHAchIdA5QSSxKchIYUCFLuGukk92Xzc5CYaRJ0LHVfxaL7RDJJLsFOhl3BO7Go89XYECoYaPKbNGla5bcWjdGghXBWXGamYUGoYDDWsRdKbq1oGxSAa8Z2dJxzrY35Obft+FdWiZ0qKZ6w4kOkvQsAApElWXqoIqIgE7Vcc3QU3LsKTquZVM9eDgYRaQggjlM5iKtWuqKLXpMjXkTPvTPIHo8vtcc/ipF7+AfSGlpSdaU5TAlquKVrxB/pH0Z8HaQopK1aYrX6VdbkLl8uhCk3klCj6wO8h8RdSUlyLqvCvqKFSAqh6vbyvEGrvc4ioTjll2Yy9EwIMjwO7FiJazbzaQGooLbLkUsWf2KP6vY0FBME8X6Dh8Hbxo0XFqQEjVKYmct2oXPKLFixc0XFLI9QKhWm1Ni51rx+HOWRcuYYp1yg6k6YiDGoHjUPmrSwkKG6yBwjftfpflqU3MKUER65ns+BfO4/A2cAhF1CrlyLiZBAAjmHUs8umtmcZL8urwty4T4YUQFJVTqYL43GG2rEi6kzKUEj/sBBHyfU4TEI0m8kSUoXpSeqR9r5lWDKUYZdwq9UyBtJkd7u2MeMs+ei3ZVcUpOgkKiaZ5PkMZYvm941z1G6ARCTvsaUIyh9bgLpt4421j3dQHx7mvXMELvv4rFKAOoD00OxFNnls1tZZP5eQ3r6ghVsgpJI1DLLg0EPo/MbKrV+4SVqBVRa41KoDV88kwW+V16P4JMn13UsFXhr/h+rXMDfWjUkb1ylo4EJJmJGXVq2FQLeK8Nabis4CPfMiRn1eL1vy9Sb98P+OzxqytSSfeyNIaHB6v0q5gStWtVi4kDLUoHpnAaCvBhJmQASKGnN1OUfL8r24vdqK9Ph24jVWeNaS5luzb8RWq4lKRHMmNtqc2XRhZM3DnSmz18mWuel7OlST2vq0rw9sQlf8A4D4OIs4a4dSvFUewex5+XsepNy7+yFSf2iSJfMa5uFRGqTMGatSu3LWnQhNzmoj6Q0lKFKICRJeu6Iq5tgA3K1EH6ONFOMs1tQSQT8GBDLo10fpTmm4O0FmCMGfxXA432o0hpcgAEtX8HC7XT2x8HI8Gxtc+jny/lXk5t3Vp6l9AMLZ/yn5NnC2v8v0Z5T3LXIl1apiRZGnwu2rSncUs7nIMb6ayvDJQnUAVbzLVuFXPgwHSX2XiYQ7I7mUXMKP8Y7Hn5e1R5OIg9C6P0H9TYylJ7PseePho/B3fY15X0GuCGblUfa/qcNw/tdv1GG4f2/Y35X0GuGXVjff/AKjD/dn+EOxxVhP+2f7Q15e1LXCrOrIMOk9D3PrTjLfjIISQkBWoQmCTk139ZZHTlRu8vY9eeC1cuGEIUo8A4xQtJKSkgihEZP0j9bZn4O362wa9/wCYc+V9C15ppV909xe6FfdV3F+oDE2lZQ5guo6Dva8/YteR6F/dV3F38K59xXcX66FDonvZNY/6uf1PYa8wQCLZkRUOM+mxfv3P6h/8Q+aesumo6FkdXZqMgdHcOjTg1K3LhJyanbLGFT0oU+et27l4FNtJUQZL7O2CWhYBfhYlSTTVqHaDLnclOUJGBxCqFGn+ow8/Q4gGNPbIh+gm6kfiB+bEpalD0zwJAH1r8ny/qX2aa8/GCvLEgAjqC9/Q4gfh+YfT4JSjYBI3UJEDfo1nWjoocSPg3edl+i2vP/0eJ+6O8O36HEHYf3B+g6rZPvA9rJKNnH6l9IPKuAGAvdEj+IOXh8OuxdTqj1ERXoX2np6Fpd2PHtR19od8edtPaQL+AuLvXFen1LUc+Lhjy256jKQRECc/g+/WpMqruXGC09Z5V+jz86NrnLeBWE1KfgXdWEShMa9OpYik16Hg+gqckK7afa0vGC5oSqghaaCesZ9GTldPairwFuCpS5gbcHBOFtIFs66LO9CARM1L6S8UKw6yaekyOhGYfM4nT+isnNVM6kEu5bf74TjVmpjqyIVQhw2QPsCUMnR2GTxhG9eO8sNcBzrebghqlsSWyrqBZxF0fsVaDv6okNnBeYb3JH9ZfV4Mek8g1mvVz5B5wLGIVa8K2NJJC5mPdlMOIry3GqopQUOK36XoPia5j06dMUzmebNVqXGnK+V15zaw960Y0iuu1nQKIz7t3U+XY0n30nf3i/QlAnR7o0kk0mZ7aMslkuDldebIw16yuVH1hSazsqRm5f6PzAf73/mX3UeoKhJ58HeWpc33VyuyT0eRY3CYhGlV5QVU1knbdxL+HVaURcAkgK737MQlQggHm+K83TS2vmk/VlutuHK9QjeVBBuepIPpMU+btdwWKTet3JGqdKSCScqTSkB2sXBauWlqoFWk/D2P0uXE+a053Mv8uHQnzO2T6gof1fRol7DYm4rUu2sz90A+1+mm4lOagO1g8e2criP7g9d9o4HkisKSYQi5PRQgs48uxMVtlI6n7H60LqfvJPaHJTiR972ubp9PHR5ev76R3s4wEV1/J+sKRau5pHMZtJXg5/lq1cFUeFvIY86/Qk/i+TQMVa8BYAMyJfoV4XLP8wBIfIX79lap0kmImW+Nup+FP05Vct5+tBVtwyYf0/qvCvo5Haavf1StaFBPuJKR2uib983LoAErHqHZD07CyLaFLSmT6kyaZGJ+jkeAg3fDCgfTqJpTg0VKriboAnUCAB2Qym5cF8kj1REAZN9/0Mr/AKVHiFGoyADtuzfpkg6dUkCY4NOC7wu6o1KKOBpPBgVdui7qIIJTEdewvPL6kPcRbFvWDnQA0rLUk4VMZj6vlJUYtx+PLeTR9HruJyCqbEe1u76m5Ikl1eNvoarPXV6wLy7AvAY2BebtJFJ4/Jid4OwbgsByW6s3hLz0nueFByaIOT1dp6kuQmzqn1JptLfg/wDZLQAUZUKl2gMaklJDzZsJOkbKdQBuo9zCGSGkpgCNyPn7HM02jHrSO1TSfDUTEZs36e5ElJDnPcYU9KAP5w+ZZk+Fmb3cD8GkeBcp6XYWbtfSXGe5FhYR4YKCVAqNTyDSCGr6FIw6AoEHUrugNLLcAMOsORDwh6LxDIbZ4Y4bUkpLXbb5kUfQWSC2x5Tp0lpT5LEDwsSTxCg+sScmmY6wVo1ipRn/AE/YyMPgrLu6UBVtCjqygU+TmWTcuJ9VOgNCBHGJHJ8ngcXo/ZryOR6H4F9wSImX53OXjf8Aiuucp9wg4GfB/iV9Wuc2iYH+UeC1fVrFHHL/AGrM4HB20piqQ6yAxpVM/nLdyEsITNEtOUAL1qkV9rmlaU6ZNCRJFY7nDob9r1aq9CIrxze/CdqhWIT6jpTma0YtUNqVY1KlS8zkn7WLVh/vXD/CMu942JX1tMxigbJrukxyU1nXhRmu4P4GlYnwV4e4u0vVwIg8+TqcbsvufaNiLts2bpBTJQfo+Nxd8KRatp/AgauKo9ga5jMRbRa8MAFakiYj0j4vgX1fj49fuawZgws4fWmpD1iDs5C7ZDsGyxbQ1K2YaS1O1mGJenYfEItW4VmeXtIco420nML/ALZ9r8mxS1eJAiAkDIc2kSXpOOwtey/vXC/eUP4S3+9MJ/kP9qvg/F3jrwide0/vLCf5R3K+Dk/r8L/mR8/g/DW2eEPXuX67C/5kd7v+tw3+a33vwqrxnhBr3X9Zhv8AMjvaD5jds3rSQi4hRChQGuRflEu6TBBc+EXLljsZRcu4ZJWkJTbTqJNBBJjm/SfGtHK4g/xD4vxYJN0rSBWJHY0lqcF8rr3ZVywTVdvtIafcs4JVVeH/AHAPxmXZ14+7J6mrD+XfeT2LdRg8Ccl/+b8slvU6z3oeqDCYZJ9GIUnlcDk/p8gnF3O0pL8jkMoI2LXj7h6Tc8vuLFL4VPUlht+S6vfuAf0j4vgBq2KmpIxOKt0C18jJc+N9T16P+6AgekhUdR7Xx5w1z9VfEQpGjISKh3HmmLAjVH8P2NJTj76Lt24FVuaQTE+68PC99r2US1a/bXkn8OkzkZ6sPoRiQdQgJzzk1aQu6q4ta1EyrM9XEMSzx9ydGq7aN4K20kEiRXscdV6341tQyEzn7Whts8SKmpCsTqmEzPy+LWDiLQPvEvkXjV4yhkNvqUIuIqPDVwUkK+rlFN4jJA/pQgfQOtnqvXJItLuGEpUrkJamMBij/s3O5zjavTJKmfwrivxr7T9rNnqWoyPLrqhJGnPNSdusl0VhEpBlYPSILlfpOqi3+kFfV8vtcbP/AECX4V1FU98j4sZ8ZIqc+IascJApVxxh1nb5/B3/AI+paTSq6aajyli0nh3tZGGUTA0ntahbwN9fuhH9wdf4+o7cppPUM+lRpKX1yMPiEH0kA9AQWY28cPvR2QzZ6n24bw1cHJNlQEyD2H2h9cE4wwNc8JFPY5Jw+Nu01pUOmofBrePrA4UWircNQOCuJAJXaE/9x84l9ijy3SJupPZcSB/8SzHD4an7Iz/WVDtoHN5cZ9nlcMcOpMftrZ5FVO8B6q0rM3QeE1fpKMPhVQDZRM1I1wf/ACaocNhUj/8A50c4Ufa58+J+NeQC1P4x3mjVkIu6RoE8go9r9SRdRaH7LDEcraqsyL+LJI0K/wD1x7XPlPQseVKReCD4iViogqSRtxaMp+0YpGJv4VabiKj1A0Bp9j8eKZal2pwINliSqDDlRL2aIhDFDkl0YEZy7SoLAWMOkO+tq1JfQ20lXJ8DYv6X19nEgtuSkfG+VrtzdsAqTukVKfsafhcWlPpuDUOZHcfi/WsPfAUK0ZsX5PhsYNaItLO6cjzDNnxZsa5v2QsN+7lAJSFIkz6lUk8ZfWDBYc1Cc9wo/F+O3/LsXgyZSVJ+8mo+IcW15hes+6pQ7Xp+lx5dy/3LzvH5j2w4HD/cPeXn6HDxGk/3H4vzy355dHvaVcx8Iaqnzwb20nkuPqh438PL0lX58XTnCYaY0qHLVDGMBhytK0lSSNuve0T9+I/wn/8AYn4OOrz0f4k9tyfohr9Pl/5V58fV1QwFjfUcsz0+PR2/d+G+4Twkvz2559d/Cm2nsKvqR9HyV7zTE3c7q46A6R3Jh1+lfvC8o9YxFvy/Dpi6uI/DqlXKBXvflmMxttcpw9s20GhKjKiOWQ+b5NV0qcapZ4Se6tVLx3h2h64nVQGZ1blupWZAWNnAea4KG3Z2hysFqdowXCiWq4W3ruoTsSKuah6YnyLD3AFrXd1KAJgihjkxq/49h4pdug8dJ9j6VWIXEak8wAwpv3SPfB46R9jjyvqvpzv/AK7Yn+bcjkljP/HLNf2y+HpHzq+r/U3BmUd32t/ql/8AQ/nm68r6jI41X/HEQNN9XGUj5VeD/jaZrfVwhH2vsjirm2gd59rqMWuMknv+LPK+oyON/wDW0x/PVP8AQPi7f+uJ/wA6v7B8X2v6xX3PmxjFnTBHbP2N+V9SyON/9cRP85X9rIP+PoBnxDI2IkPsDjDT0fN5+tH3D3tbR049XkKSSrxVScwKMB/48n/IY/PB9x+tTulXydv1tvfUOxm0+nnqv+OmYF2OJEg9zjj/AI8sz+2AI20n5Vfpf61ESJnp9r39Yg9eUfa35ciyPLf/AF+5BPipptFfqwn/AI/fgEXLZnm/Wf1Vo0M9zGnE2zPqI6SCzy5HjyY+QYofjtHtPwcM+R4wTRBjbVV+0nE2gPfnkD9GL9VZ+/HMH6Zt+dGPFf3NjokIB5LT86uv7qx4MeGf70x3y/bjiLWetPH/AEzdf1Fmn7REcT+fmzzox4uny3Hk6TbUOahH1ZFeUYsV0hXIv2bx7VP2iB/EJdxft/fT3hnnS8Xh37rxf+I/J1PlWK/xF+5+KgU1J7x9HbWnqzzvpCx4J+68VE+CqHBVgryc7ahzD+hfESTmJ5vCU8Pkzy9oMfOf6a591Xc9GFvKyQo9hf0MYHsn2FiKh+c2eXsePMhh7/8AjX/aXOThMQQf2an2Bx2HT+KeQdFeZWE5ajyHxfLh9OZGCxCpi2O0w5SfL7+ehI5q+Etc/elrov5OOfNhtbPaXPXqXSH+7LxzUO/7GceV3IjWkdhZP3t//MT/AFPf3sdrY/u+xnR6xPla/wAV0T/T9rkDypI/3FdgHxcc+ary8NIPMlgPmd85JQOw/FnRbC0PLkbrV3Bz04VKclK+XwfI/vDEn8SR/CGM4/EqprjkAzYPJ3Bw1tWcvP0tmpI23Jj6vz44q8rO4tx13bi6FSo58WtnoPJ6MnD4UH0oRxrPtcpFuwRKUI7n5TBTvTozpuLTQKUO0w1vsnyepFNlOaUdwdotp/CgV6B+T8686smqaT+e9vy9h5PTlYqwhWkrTP56MoxNg/7ie9+WSn7okjOHWQKV+Lny9h5PVf1Nkf7iewz9HGVj8On8RPIF+bSeL09dmeV9h5PRD5hhxuo/wvyy5ZTruFE6SZTPQ/BqPpmJ3qPz8XcaevCvNk5dnL280uJKVlmSpq2OslKtXe+dBh96yoWJiCg2VMDYdYDJLqwwo6OQi4pDo22nC9axpGb7TDeZafxdj8rh5UNsvF9L2fMbNwQogMd/y/BYwe4mT+JFD8n86JvLTkS1e15hetnNzi9dxf8A+NqEmzen/qse0fB8Ne8sxtjO0TxTCvpV9Xb89uAQWrp86QqJo68uUGT0ePqRdT7yVjmkhxdRfu372sVFC4asVgLnvWrZnqkM/UqvH2eJy6P069Y8uuVRNs8DTuL5C9YTbPpWFjq7nKX7Z2X0IEF30uRIY5evTPtR47F0cWqxj2HsOWA81BgOQA6skOVtdXfJiLDGD7LB2zE/N8pZRrUA+5mAEpHu58YfPzuQJGkE+9G3P5O2ckTJpWgHFhSZJPP6bOiiooNRvzjaj40jRcp6h0ilf9G/EIEGSeH2Fx8veUSMpDskAg6SM6devMFgabilkR1zOf2MyVmK03O9XH1gyPn9rFQTXPKN+DQ1P1qEwomrzxjFKz3OGBTPLf7GCKTMzwb0kw3lZ9jKMVuRTJpxjf55PSE1d+VIteOg8HcXUK3AaB4YImnQMYSN9np50Onpwl4RD5yla8eLtrIGZq68/Y9dCQOLppGzQBdWdzSkl38QpBqVdOTrz9hpc0ukQ0kXlJA3k90M4vSYMZ5t+UNMzdI7XG8VNa/6O/iI2L02Gvp5dzroH3R3B211iXXU7Chtj7o7mPR/0cqXmof6MCP4Yz0unhiCIocxt3ZOTP5l5IPVs2AQNMqCdgCQHOTdAEH1c/i0sqYpaDnRl2uQkTTr1cEjmyh8LJK9ImaNpIMzt9HHq7BLQSuMCsu9acWKDQfmWTKlXJLTnTJvY0b73o3zr+aNG0bc3ekju+yW9IptH5hvdrQMaA9HkTlHVjpPTtd4yn5MIQSmCBNZdAVigFCM3cZRM16fJ0lKakGmzQFjUHumBUz8GPWTnPWjuT09jWgSCgGa8OrsJPPYfUOguBNOlQesjLv3Y/EmMhnWjZpmwnPjzdQMyYgfkOGFpEyocubILqJ4MJpyMgTwZfdy9VMiMuPY6BVqCRM/IdQyFaVCa9DX6lyeGu34tuFVMd46vzS6g2llJ2fpgWBUSKdfl2vksbY1ftUVG46fY+vhz+mzlpd5YW32BMlnlpwLNqYaa24wLJLRDNump7LDMh0hlBDctgGHVyYeNpAq9qzw3DlQNWzLM8hgRdDrpct42lF0u+lnl1lsjCWTJil2aDC7vQlskBgZMBxhUupMtUwlk3FyQdKSJPsZejdNhbGlGo0Jy5dXNE5SY3Z/EjOkfTk6qUPwqo/Pt1F7OiDvTON44MZBVWvq6bc3gUDmXSQKg5uNJJKYCRBA59OvQsSTAIiral+mI7tngXuYni1o1dUgACvU7dXGjrJ3gMvicBzdpzFKgZOjB0gyQD25djsnOtPzl+S8SYSdjtWjZWKdWtiQ1A6tyOuQeiAQJnPPfubJB3htJEVB+TZCDoZ7GIqM14MoImMp3YzvVhh6a+zd4mvp6HapLPBSCU7cp5vABPp360FG+jxUSfTVNKOPXujaQWYgmFGRJJmn5DCMwpM5ujD1EHr1H54tquKM0jKvCXZXGn+r3LhPKrCW8RIiZP05sZWTWAWPem31diMqFhg6zkKMovrHF30cAObsEiswK5n/AEaCR4sEzJ6Udk3c53yhxlEA1PwYqQBOfy4u/KjS0mV5JVzgs4QvZB7i+Ut4i7glgBSrlsn3TWOXFqR80xAE+EiBTeflTufRL/Cyz4Vw/gLAbSxmg9z57983/uW+4/FlPnVyB+yRPMw77NAy3ZWEZux/Pc+JkJNc3cGKksJz7HZfuns+rRLquKGQBk0ciTLinJPNyFfnvYY4MbvJox7h6fa4MeeI9jtI/wBXD27fYz/iSwliutIeanD/ABfxf/ZyU/h5n6tmONUitTNOAeFXU9357nv+8n+k/Vw1b8/YWgkTxZBqVTujdgG38TUsP79vsaUunC37v4COKqfa5B8svfeR2kn6B96GUvTG/jHnB8pvkyLiOVfgxq8vupSSq5bEc/bD9N2fO4z+UtlPI51Hl11YB1pE19QPs+Lmfuu59+33KfYWvdR/SPo5zWJyOKHlq97iD/CafMO48tUDS6NP3Sk/XU+wdg6yHkeN4/ya5aSblr9oPxJAgjiBJo/O39RXv5Vz+hX0fy8c31camqu7G7PVIoLJLjsjAOC9JccMrCOXsl0esWkBRdtTA9DCH1NlTC6lhL6nksYeFhjS3LEXViUiXmpgdSxKTrDetw3ZgTvFgZOKVSxPQ6Ds8D5ZcxJC7k27X3iM/wCn4mj9PT5fhUJCU3SAOik15vMH/wD51vkfqxvmvbRc+X2VEnxjWlNLH+67P+VZ/t9gcxGTVEvLIRB/dVmIFy58ng8ptD/cX3B9WlkbyByI8ptD/cufJnHltoHNXyh9S6ufGHOnIHyq3+Fa08Bpj5hseVoGalq5mD8h7H1zs3kDkP3Zh9/GH8fwDt+68Mf8n932Pp1ZOqcm8noTmT5ThSIPi/3/AGN/uvDAU1yMpWX1BeN5A5X93oqNPL1F6ny5E+oEDgsznnk+qesyG5S9gLaUK8Mq1RuZng+FOoU6P11T8nX7yu36vHlGdAmobUa5D2N/iH52YlZns9rxQZGW/DN1UNp32ZE+8nl7C2vMPQwomKmjwjfVyq7D/wCwYVbcw2Fk6ufZRuZB5dXIt5DtcNPulgbKjQMVYNYO+7MjMf1D6sJzW6IME1qfqDwZoqagfnPmwDMc2Y+xsI6kJUDqAPyPYwG1aMQCO1yz7Cxp95P56s2qf//Z"};
/* caption lines that survive the original content being hidden (innerText loses <br> line breaks on hidden elements) */
function capLines(el){if(!el)return[];const t=el.cloneNode(true);t.querySelectorAll("br").forEach(b=>b.replaceWith("\n"));t.querySelectorAll("p,div,li,h1,h2,h3,h4,h5,h6").forEach(x=>x.append("\n"));
  return t.textContent.replace(/\u00a0/g," ").split("\n").map(x=>x.trim()).filter(Boolean)}
/* on the GitHub dev copy, pages live under a folder (e.g. /usg-dev) and data comes from saved JSON files */
/* the folder comes from the address actually being visited, so renaming the repo can't break the site */
const MIRROR=!!window.USG_MIRROR,BAKED=(window.USG_BASE||"").replace(/\/+$/,""),LIVE="https://usg.princeton.edu";
const BASE=MIRROR&&BAKED?"/"+(location.pathname.split("/")[1]||""):BAKED;
const PATH=((BASE&&location.pathname.toLowerCase().startsWith(BASE.toLowerCase())?location.pathname.slice(BASE.length):location.pathname).replace(/\/+$/,"")||"/").toLowerCase();
const asset=u=>MIRROR&&/^\/s\//.test(u||"")?LIVE+u:u;
/* links inside the dev copy stay inside it; files still come from the live site */
function mirrorLinks(R){if(!MIRROR)return;(R||document).querySelectorAll("img[src^='/']:not([src^='//'])").forEach(i=>{const u=i.getAttribute("src");if(!(BASE&&u.startsWith(BASE+"/")))i.setAttribute("src",LIVE+u)});(R||document).querySelectorAll("a[href^='/']").forEach(a=>{const h=a.getAttribute("href");if(h.startsWith("//"))return;
  if(/^\/s\//.test(h)){a.setAttribute("href",LIVE+h);return}if(BASE&&(h===BASE||h.startsWith(BASE+"/")))return;
  /* a link built under an old repo name: swap the folder */
  if(BAKED&&BAKED!==BASE&&(h===BAKED||h.startsWith(BAKED+"/"))){a.setAttribute("href",BASE+h.slice(BAKED.length));return}
  a.setAttribute("href",BASE+h)})}
const COMMITTEES=[
 {slug:"academics",name:"Academics",chair:"Isaac Bernstein",match:["academic"]},
 {slug:"campus-community-affairs",name:"Campus & Community Affairs",chair:"Anaya Willabus",match:["campus","community affairs"]},
 {slug:"dei",name:"Diversity, Equity & Inclusion",chair:"Morgan Hoang",match:["diversity"]},
 {slug:"mental-health",name:"Mental Health",chair:"Aakansh Yerpude",match:["mental health"]},
 {slug:"sustainability",name:"Sustainability",chair:"Gianna Maltbie",match:["sustainab"]},
 {slug:"university-student-life",name:"University Student Life",chair:"Oscar Barrios",match:["student life"]},
 {slug:"social",name:"Social",chair:"Vivian Chang",match:["social"]}];
const NAV=[["Senate",[["History","/history"],["Senate members","/senate-members"],["Budget reports","/budgetreports"],["Constitution and documents","/usgdocumentsandcharters"],["Administration documents","/administrationdocuments"],["CPUC information","/cpucinformation"]]],
 ["Class gov",[["Our mission","/ourmission"],["Class of 2027","/2027classgovernment"],["Class of 2028","/2028classgovernment"],["Class of 2029","/2029"],["Class of 2030","/2030"]]],
 ["Committees",[["All committees","/committees"],...COMMITTEES.map(c=>[c.name,"/committees#c-"+c.slug])]],
 ["Resources",[["Events calendar","/events-calendar"],["SGRC club approval","/sgrcclubapproval"],["Projects Board funding","/projectsboardclubfunding"],["Mental health resources","/mentalhealthresources"],["University resources","/universityresources"],["CPUC","https://cpuc.princeton.edu/"]]],
 ["Get involved",[["Working groups","/workinggroups"],["Elections","/elections"],["Contact us","/contactus"]]]];
const PRIORITIES_DEFAULT=[
 ["Mental health",["Push for expanded, higher-quality care at CPS, starting with a public report on its current status.","Treat mental health holistically and systemically, beyond CPS.","Specialized care for students in disciplinary processes and students seeking gender-affirming services."]],
 ["Community",["Back student groups as they rebuild campus life.","A comprehensive resource guide to ease first-years into Princeton.","Long-term partnerships with town food vendors to widen dining options fairly."]],
 ["Diversity, equity, inclusion",["Make the DEI Committee and Chair permanent USG roles.","Expand resources and accommodations for students with disabilities.","Elevate student concerns about sexual misconduct.","Expand financial aid, including permanently removing the expected student contribution."]],
 ["Academics",["Keep building minors alongside concentrations and certificates.","Programming that informs and celebrates concentration declaration.","Wider access to academic accommodations.","More flexible leave of absence policies."]],
 ["Sustainability",["Make sustainability a core principle in USG and University programming.","Scale up waste reduction, including the annual dorm move-out and resale.","Accessible sustainable options in housing and dining."]],
 ["USG and University resources",["Pop-up USG tables and feedback points where students actually are.","Keep connecting students with decision-makers through USG Town Halls.","A streamlined process for student seats on University committees."]]];
const HOURS={0:[16.5,19.5],1:[16.5,19.5],2:[16.5,19.5],3:[16.5,19.5],4:[16.5,19.5],5:[14,17],6:[14,17]};
const MON=["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],MONL=["January","February","March","April","May","June","July","August","September","October","November","December"],DAYS=["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];

/* images: use Squarespace's own CDN at a sensible size */
const sized=(u,w)=>{if(!u)return u;if(/squarespace-cdn\.com|static1\.squarespace\.com/.test(u)&&!/[?&]format=/.test(u))return u+(u.includes("?")?"&":"?")+"format="+(w||1500)+"w";return u};
const mediaURL=async u=>sized(u,1500);
const hydrate=()=>{};
const imgSrc=im=>im.getAttribute("data-src")||im.getAttribute("data-image")||(im.getAttribute("src")&&!/^data:/.test(im.getAttribute("src"))?im.getAttribute("src"):"");

/* ---------- time ---------- */
function nowNJ(){const p=new Intl.DateTimeFormat("en-US",{timeZone:"America/New_York",year:"numeric",month:"2-digit",day:"2-digit",weekday:"short",hour:"numeric",minute:"numeric",hour12:false}).formatToParts(new Date());const g=t=>p.find(x=>x.type===t).value;
  return{day:DAYS.indexOf(g("weekday")),h:(+g("hour")%24)+(+g("minute"))/60,iso:`${g("year")}-${g("month")}-${g("day")}`}}
const clock=h=>{const H=Math.floor(h),M=Math.round((h-H)*60);return((H%12)||12)+(M?":"+String(M).padStart(2,"0"):"")+(H>=12?"pm":"am")};
function njParts(ms){const p=new Intl.DateTimeFormat("en-US",{timeZone:"America/New_York",year:"numeric",month:"2-digit",day:"2-digit",hour:"2-digit",minute:"2-digit",hour12:false}).formatToParts(new Date(ms));const g=t=>p.find(x=>x.type===t).value;
  return{date:`${g("year")}-${g("month")}-${g("day")}`,time:`${String(+g("hour")%24).padStart(2,"0")}:${g("minute")}`}}
const fmtDate=d=>{const[y,m,dd]=d.split("-").map(Number);const dt=new Date(Date.UTC(y,m-1,dd));return DAYS[dt.getUTCDay()]+", "+MONL[m-1]+" "+dd};
const fmtTime=t=>{if(!t)return"";const[H,M]=t.split(":").map(Number);return clock(H+M/60)};
const when=e=>[fmtDate(e.date),e.start?fmtTime(e.start)+(e.end?" – "+fmtTime(e.end):""):""].filter(Boolean).join(", ");
const daysAgo=n=>{const d=new Date(nowNJ().iso+"T12:00:00Z");d.setUTCDate(d.getUTCDate()-n);return d.toISOString().slice(0,10)};
function gcal(e){const d=e.date.replace(/-/g,""),st=e.start?d+"T"+e.start.replace(":","")+"00":d;let en;
  if(e.end)en=d+"T"+e.end.replace(":","")+"00";else if(e.start){const[H,M]=e.start.split(":").map(Number);en=d+"T"+String(Math.min(H+1,23)).padStart(2,"0")+String(M).padStart(2,"0")+"00"}
  else{const x=new Date(e.date+"T00:00:00Z");x.setUTCDate(x.getUTCDate()+1);en=x.toISOString().slice(0,10).replace(/-/g,"")}
  return"https://calendar.google.com/calendar/render?"+new URLSearchParams({action:"TEMPLATE",text:e.title,dates:st+"/"+en,ctz:"America/New_York",location:e.location||"",details:e.description||""})}

/* ---------- Squarespace data (same site, so no cross-site limits) ---------- */
const jsonCache={};
function sqJSON(path){if(!jsonCache[path])jsonCache[path]=fetch(MIRROR?BASE+(path==="/"?"":path.replace(/\/+$/,""))+"/index.json":path+(path.includes("?")?"&":"?")+"format=json",{credentials:"same-origin"}).then(r=>{if(!r.ok)throw new Error(r.status);return r.json()});return jsonCache[path]}
function normEvent(it){if(!it||!it.startDate)return null;const s=njParts(it.startDate),e=it.endDate?njParts(it.endDate):null;
  const loc=it.location||{};const tmp=document.createElement("div");tmp.innerHTML=it.excerpt||"";
  return{id:it.id||it.fullUrl,title:it.title,date:s.date,start:s.time==="00:00"?null:s.time,end:e&&e.date===s.date&&e.time!=="00:00"?e.time:null,endDate:e?e.date:s.date,
    location:loc.addressTitle||loc.addressLine1||"",image:it.assetUrl?sized(it.assetUrl,750):null,url:it.fullUrl,description:tmp.textContent.trim().slice(0,300)}}
async function loadEvents(){try{const j=await sqJSON("/events-calendar");const raw=[...(j.upcoming||[]),...(j.past||[]),...(j.items||[])];
    const seen=new Set();return raw.map(normEvent).filter(e=>e&&!seen.has(e.id)&&seen.add(e.id)).sort((a,b)=>(a.date+(a.start||"")).localeCompare(b.date+(b.start||"")))}catch(e){return[]}}

/* ---------- shell ---------- */
let hdr;
function band(crumbs,title,extra={}){$("#bandIn").className="wrap"+(extra.side?" cm-hero":"")+(extra.narrow?" band-narrow":"");
  $("#bandIn").innerHTML=`<div><p class="crumb">${crumbs.map(([l,h])=>h?`<a href="${h}">${esc(l)}</a>`:`<span>${esc(l)}</span>`).join('<span aria-hidden="true">/</span>')}</p><h1 class="xw">${esc(title)}</h1>${extra.tag||""}</div>${extra.side||""}`}
function clearTheme(){$("#bandStk").innerHTML="";$("#bandStrip").innerHTML="";$("#v-inner").style.removeProperty("--acc")}
function wireShell(){
  $("#yr").textContent=new Date().getFullYear();hdr=$("#hdr");
  const onScroll=()=>hdr.classList.toggle("solid",scrollY>40);addEventListener("scroll",onScroll,{passive:true});onScroll();
  const link=(l,h)=>`<a href="${esc(h)}"${h.startsWith("http")?' target="_blank" rel="noopener"':""}>${esc(l)}</a>`;
  $("#navList").innerHTML=NAV.map(([n,ls],i)=>`<li><button class="nb" aria-expanded="false" aria-controls="d${i}">${esc(n)}</button><div class="dd" id="d${i}">${ls.map(([l,h])=>link(l,h)).join("")}</div></li>`).join("");
  $("#drawerNav").innerHTML=NAV.map(([n,ls])=>`<details><summary class="xw">${esc(n)}</summary><div>${ls.map(([l,h])=>link(l,h)).join("")}</div></details>`).join("");
  $("#fcomm").innerHTML=COMMITTEES.map(c=>`<li><a href="/committees#c-${c.slug}">${esc(c.name)}</a></li>`).join("");
  const nbs=$$(".nb");const closeAll=ex=>nbs.forEach(b=>{if(b!==ex){b.setAttribute("aria-expanded","false");$("#"+b.getAttribute("aria-controls")).classList.remove("open")}});
  nbs.forEach(b=>{const d=$("#"+b.getAttribute("aria-controls")),li=b.parentElement,hov=matchMedia("(hover:hover)");
    const set=o=>{closeAll(b);b.setAttribute("aria-expanded",o);d.classList.toggle("open",o)};
    b.onclick=e=>{e.stopPropagation();set(b.getAttribute("aria-expanded")!=="true")};li.onmouseenter=()=>hov.matches&&set(true);li.onmouseleave=()=>hov.matches&&set(false)});
  document.addEventListener("click",()=>closeAll());
  const drawer=$("#drawer");const dOpen=o=>{drawer.classList.toggle("open",o);$("#burger").setAttribute("aria-expanded",o);document.body.style.overflow=o?"hidden":""};
  $("#burger").onclick=()=>dOpen(true);$("#dclose").onclick=()=>dOpen(false);drawer.addEventListener("click",e=>{if(e.target.closest("a"))dOpen(false)});
  /* keyboard: tabbing out of a dropdown closes it; Down arrow opens it and moves into it; Escape closes and returns focus */
  nbs.forEach(b=>{const li=b.parentElement,d=$("#"+b.getAttribute("aria-controls"));
    li.addEventListener("focusout",e=>{if(!li.contains(e.relatedTarget)){b.setAttribute("aria-expanded","false");d.classList.remove("open")}});
    b.addEventListener("keydown",e=>{if(e.key==="ArrowDown"){e.preventDefault();closeAll(b);b.setAttribute("aria-expanded","true");d.classList.add("open");const f=d.querySelector("a");f&&f.focus()}});
    d.addEventListener("keydown",e=>{const ls=[...d.querySelectorAll("a")],i=ls.indexOf(document.activeElement);if(e.key==="ArrowDown"&&i>-1){e.preventDefault();(ls[i+1]||ls[0]).focus()}if(e.key==="ArrowUp"&&i>-1){e.preventDefault();(i>0?ls[i-1]:b).focus()}})});
  {const _dOpen=dOpen;const burger=$("#burger");
   const trap=e=>{if(e.key!=="Tab"||!drawer.classList.contains("open"))return;const f=[...drawer.querySelectorAll("a,button,summary")].filter(x=>x.offsetParent);if(!f.length)return;
     if(e.shiftKey&&document.activeElement===f[0]){e.preventDefault();f[f.length-1].focus()}else if(!e.shiftKey&&document.activeElement===f[f.length-1]){e.preventDefault();f[0].focus()}};
   drawer.addEventListener("keydown",trap);
   burger.onclick=()=>{_dOpen(true);setTimeout(()=>{const c=$("#dclose")||drawer.querySelector("a,button");c&&c.focus()},50)};
   $("#dclose").onclick=()=>{_dOpen(false);burger.focus()}}
  document.addEventListener("keydown",e=>{if(e.key==="Escape"){const open=nbs.find(b=>b.getAttribute("aria-expanded")==="true");closeAll();if(open)open.focus();
    if($("#drawer").classList.contains("open")){dOpen(false);$("#burger").focus()}}});
  $("#logoBadge").hidden=false;$("#logoImg").src=LOGO;$("#logoText").hidden=true;$("#flogo").hidden=false;$("#flogoImg").src=LOGO;
  const st=()=>{const{day,h}=nowNJ(),[a,b]=HOURS[day],s=$("#sticker");$$("#fhours li").forEach(li=>li.classList.toggle("today",li.dataset.d.split(",").includes(String(day))));if(!s)return;
    if(h>=a&&h<b){s.classList.add("open");$("#st-main").textContent="Open now";$("#st-sub").textContent="until "+clock(b)}
    else{s.classList.remove("open");$("#st-main").textContent="Closed";$("#st-sub").textContent=h<a?"opens "+clock(a):"opens "+DAYS[(day+1)%7]+" "+clock(HOURS[(day+1)%7][0])}};st();setInterval(st,60000);
  document.addEventListener("click",e=>{const b=e.target.closest("[data-lbu]");if(!b)return;e.preventDefault();$("#lbImg").src=b.dataset.lbu;$("#lbCap").textContent=b.dataset.caption||"";$("#lbCap").hidden=!b.dataset.caption;$("#lb").showModal()});
  $$("dialog").forEach(d=>d.addEventListener("click",e=>{if(e.target===d||e.target.closest("[data-close]"))d.close()}))}

/* ---------- tidy Squarespace content in place (keeps forms and embeds working) ---------- */
const FILE_RE=/(\/s\/[^?#]+|\.(pdf|docx?|xlsx?|pptx?)(\?|#|$))/i;
function stripCode(R){R.querySelectorAll("script,style,noscript,template,link").forEach(x=>x.remove());
  const CODE=/(\$\(\s*(this|document|window|['"])|toggleClass\(|addEventListener\(|function\s*\(|\}\s*\)\s*;\s*\}|^\s*\}\);?\s*$|<\/?script)/;
  R.querySelectorAll("p,div,span,pre,code").forEach(el=>{if(el.querySelector("p,div,h1,h2,h3,h4,h5,h6,ul,ol,li,section,figure,img,iframe,form,table,blockquote"))return;const t=el.textContent.trim();if(t&&t.length<600&&CODE.test(t)&&(t.match(/[{}();$]/g)||[]).length>=4)el.remove()});
  /* loose script text sitting beside real paragraphs (e.g. an old accordion snippet): check every text node too */
  const w=document.createTreeWalker(R,NodeFilter.SHOW_TEXT);const bad=[];while(w.nextNode()){const n=w.currentNode,t=n.nodeValue.trim();if(!t)continue;
    const sym=(t.match(/[{}();$=]/g)||[]).length;if((CODE.test(t)&&sym>=4)||/^[\s{}();]+$/.test(t)&&sym>=3||(/[{};]/.test(t)&&sym/t.length>.12&&/\b(var|let|const|function|return|this|jQuery|document)\b|\$\(/.test(t)))bad.push(n)}
  bad.forEach(n=>{const p=n.parentElement;n.remove();if(p&&p!==R&&!p.textContent.trim()&&!p.querySelector("img,iframe,video,svg,input"))p.remove()})}
function fix988(R){const w=document.createTreeWalker(R,NodeFilter.SHOW_TEXT);const nodes=[];while(w.nextNode())nodes.push(w.currentNode);
  nodes.forEach(n=>{let t=n.nodeValue,o=t;
    t=t.replace(/call\s+1-800-273-TALK\s*\(1-800-273-8255\)/gi,"Call or text 988").replace(/1-800-273-TALK\s*\(1-800-273-8255\)/gi,"988").replace(/1-800-273-(8255|TALK)/gi,"988")
     .replace(/the Lifeline \(National Suicide Prevention (Hotline|Lifeline)\)/gi,"the 988 Suicide & Crisis Lifeline").replace(/National Suicide Prevention (Hotline|Lifeline)/gi,"988 Suicide & Crisis Lifeline");
    if(t!==o)n.nodeValue=t});
  R.querySelectorAll('a[href*="18002738255"],a[href*="1-800-273-8255"]').forEach(a=>a.href="tel:988")}
function prep(M){stripCode(M);fix988(M);
  M.querySelectorAll("a[href]").forEach(a=>{const t=a.textContent.trim();if(/^(https?:\/\/|www\.)\S+$/i.test(t)||/^[\w.+-]+@[\w-]+\.[\w.]+$/.test(t)){a.classList.add("url-link");a.style.setProperty("text-transform","none","important");a.style.letterSpacing="0";a.style.setProperty("font-size",".95em","important")}});
  M.querySelectorAll(".sqs-block").forEach(b=>{if(b.textContent.replace(/\u00a0/g," ").trim()||b.querySelector("img,iframe,form,video,embed,object,svg,input,button,hr,.flip,.usg-done"))return;b.remove()});
  M.querySelectorAll(".sqs-row").forEach(r=>{if(!r.textContent.replace(/\u00a0/g," ").trim()&&!r.querySelector("img,iframe,form,video,.flip,.usg-done"))r.remove()});
  M.querySelectorAll("p").forEach(p=>{if(!p.textContent.replace(/\u00a0/g," ").trim()&&!p.querySelector("img,iframe,br+br"))p.remove()});
  const SMALL=/^(a|an|and|as|at|but|by|for|from|in|into|of|on|or|the|to|with)$/i,KEEP=/^(USG|ODUS|ORL|PACE|SAFE|CPS|CPUC|DEI|USLC|SGRC|UHS|FAQ|PDF|US|NJ|TAC|URC|II|III|IV)$/;
  M.querySelectorAll("h1,h2,h3,h4").forEach(h=>{const t=h.textContent.trim();if(t.length<6||t!==t.toUpperCase()||!/[A-Z]{3}/.test(t)||h.querySelector("a,img"))return;
    h.textContent=t.toLowerCase().split(/(\s+)/).map((w,i)=>{const up=w.toUpperCase();if(KEEP.test(up.replace(/[^A-Z]/g,"")))return up;if(i>0&&SMALL.test(w))return w;return w.replace(/^([("'“‘]*)(\p{L})/u,(m,a,b)=>a+b.toUpperCase())}).join("")});
  M.querySelectorAll(".sqs-block.spacer-block,.sqs-block-spacer").forEach(x=>x.remove());
  M.querySelectorAll("noscript").forEach(x=>x.remove());
  // galleries: 8+ images = scanned document -> flipbook; otherwise a tidy photo grid with a lightbox
  M.querySelectorAll(".sqs-gallery-container,.gallery-block .sqs-block-content,.sqs-block-gallery .sqs-block-content,.sqs-gallery").forEach(g=>{
    if(!g.isConnected||g.parentElement.closest(".usg-done"))return;
    const seen=new Set(),pics=[];g.querySelectorAll("img").forEach(im=>{const u=imgSrc(im);if(!u||seen.has(u))return;seen.add(u);
      let cap=(im.getAttribute("alt")||"").trim();const a=im.closest("a");if(a&&a.dataset.description){const t=document.createElement("div");t.innerHTML=a.dataset.description;cap=t.textContent.trim()||cap}
      if(/\.(jpe?g|png|webp|gif|heic)$/i.test(cap)||/^[\w-]{12,}$/.test(cap))cap="";pics.push({u,cap})});
    if(!pics.length)return;const box=document.createElement("div");box.className="usg-done";
    if(pics.length>=8)box.innerHTML=`<div class="flip" data-pages="${esc(pics.map(p=>p.u).join(","))}"></div>`;
    else box.innerHTML=`<div class="wall">${pics.map((p,i)=>`<button type="button" class="poster" data-lbu="${esc(sized(p.u,2000))}" data-caption="${esc(p.cap)}" style="--r:${[-2.2,1.6,-1,2.4,-1.8,1][i%6]}deg"><div class="paper"><span class="tape"></span><img src="${esc(sized(p.u,750))}" alt="${esc(p.cap.slice(0,140))}" loading="lazy"></div>${p.cap?`<p class="gcap">${esc(p.cap)}</p>`:""}</button>`).join("")}</div>`;
    g.replaceWith(box)});
  // lazy images Squarespace would normally load itself
  M.querySelectorAll("img").forEach(im=>{if(im.closest(".usg-done"))return;const u=imgSrc(im);if(!u)return;const cur=im.getAttribute("src");if(!cur||/^data:/.test(cur))im.src=sized(u,1500);
    if(im.closest(".image-block,.sqs-block-image")){im.removeAttribute("style");im.style.position="static"}});
  // "Role / Name" captions under photos
  M.querySelectorAll("figcaption,.image-caption").forEach(fc=>{if(fc.dataset.usg)return;fc.dataset.usg=1;const p=fc.querySelector("p")||fc;const parts=capLines(p);
    if(parts.length>=1&&parts.length<=3&&fc.textContent.trim().length<120){fc.innerHTML=parts.length>1?`<span class="role">${esc(parts[0])}</span><span class="name">${esc(parts.slice(1).join(" "))}</span>`:`<span class="name">${esc(parts[0])}</span>`}});
  // document links
  M.querySelectorAll("a[href]").forEach(a=>{const h=a.getAttribute("href");if(!FILE_RE.test(h)||a.closest(".usg-done,.sqs-block-form,form"))return;
    const ext=(h.match(/\.([a-z]{2,4})(\?|#|$)/i)||[,"pdf"])[1].toUpperCase();a.classList.add("file");a.dataset.ext=ext;a.target="_blank";a.rel="noopener";
    const par=a.closest("p,li,h2,h3,h4,td");if(par&&par.textContent.trim()===a.textContent.trim())a.classList.add("solo")});
  M.querySelectorAll("a[href]:not(.file)").forEach(a=>{const par=a.closest("p,li");if(!par||a.closest(".usg-done,form")||par.textContent.trim()!==a.textContent.trim())return;
    const sib=el=>el&&el.querySelector&&el.querySelector("a.file.solo");if(!(sib(par.previousElementSibling)||sib(par.nextElementSibling)))return;
    a.classList.add("file","solo");a.dataset.ext="WEB";a.target="_blank";a.rel="noopener"});
  M.querySelectorAll("a.file").forEach(a=>{if(a.childNodes.length>1&&!a.querySelector(":scope>.fl")){const sp=document.createElement("span");sp.className="fl";while(a.firstChild)sp.appendChild(a.firstChild);a.appendChild(sp)}});
  peopleGrids(M);cardRows(M);alignment(M);soloLinks(M);
  docRows(M)}
/* a link that is the whole line ("SEE DATA FROM PAST USG ELECTIONS") becomes a caps button-link; Squarespace button blocks too */
function soloLinks(R){R.querySelectorAll("a[href]").forEach(a=>{if(a.classList.contains("file")||a.closest(".docrow,.sm,.poster,.cm-chips,.chip-list,form,.off,.ig-split,.books")||a.querySelector("img"))return;
    if(a.closest(".sqs-block-button")||a.classList.contains("sqs-block-button-element")){a.classList.add("link-solo");return}
    const p=a.closest("p,h1,h2,h3,h4,h5,h6,li");const t=a.textContent.trim();if(p&&t&&p.textContent.trim()===t&&t.length<100)a.classList.add("link-solo")})}
/* follow Squarespace's own alignment: centered blocks stay centered and the design matches them */
function alignment(M){
  M.querySelectorAll(".sqs-col,[class*='sqs-col-']").forEach(c=>{if(!c.textContent.trim()&&!c.querySelector("img,iframe,form,video,.flip,.sm-grid,.wall,.books"))c.remove()});
  const isC=el=>{const cls=el.className||"";if(/text-align--center|sqsrte-text-align--center/.test(cls)||/text-align:\s*center/i.test(el.getAttribute("style")||""))return true;
    const p=el.closest("[class*='text-align--center']");if(p&&M.contains(p))return true;return getComputedStyle(el).textAlign==="center"};
  M.querySelectorAll("h1,h2,h3,h4,h5,p,blockquote").forEach(el=>{if(el.closest(".sm-grid,.sq-cardgrid,.books,.docrow,.wall,.usg-done,form,.chip-list"))return;if(isC(el))el.classList.add("is-center")});
  M.querySelectorAll("ul,ol").forEach(l=>{if(l.closest(".sm-grid,.books,form,.chip-list"))return;const lis=[...l.children].filter(x=>x.tagName==="LI");if(!lis.length)return;
    const centered=isC(l)||lis.every(li=>isC(li)||[...li.querySelectorAll("p")].some(isC));if(!centered)return;l.classList.add("is-center");
    if(lis.length>=3&&lis.every(li=>li.textContent.trim().length<=70&&!li.querySelector("ul,ol,img"))){l.classList.add("chip-list");
      lis.forEach(li=>{if(li.querySelector("a"))return;const t=li.textContent.trim(),m=t.match(/^(.*?)\s*\(([^)]+)\)\s*$/);if(m)li.innerHTML=`${esc(m[1])}<span class="chip-note">${esc(m[2])}</span>`})}})}
/* rows of side-by-side "heading + text" columns (Fall / Winter / Spring...) become one grid of matching cards */
function cardRows(M){const rows=[...M.querySelectorAll(".sqs-row")].filter(r=>!r.parentElement.closest(".sqs-row"));let run=[];
  const flush=()=>{if(run.length>=2){const g=document.createElement("div");g.className="sq-cardgrid";run[0].row.parentNode.insertBefore(g,run[0].row);
      run.forEach(x=>g.appendChild(x.col));run.forEach(x=>{if(x.row.isConnected&&!x.row.textContent.trim())x.row.remove()})}run=[]};
  rows.forEach(r=>{const cols=[...r.children].filter(c=>/sqs-col/.test(c.className)&&c.textContent.trim());
    const tag=c=>{const first=c.querySelector("h1,h2,h3,h4,p,ul,ol,hr");return first&&first.tagName};
    const ok=cols.length>=1&&cols.every(c=>/^H[2-4]$/.test(tag(c)||"")&&c.querySelectorAll("h1,h2,h3,h4").length===1&&!c.querySelector("img,iframe,form,video,.flip,.sm-grid,.wall,.books")&&c.textContent.trim().length<1200);
    const same=ok&&cols.every(c=>tag(c)===tag(cols[0]))&&(!run.length||tag(cols[0])===tag(run[0].col));
    if(ok&&same&&(cols.length>=2||run.length))cols.forEach(c=>run.push({row:r,col:c}));else{flush();if(ok&&same&&cols.length>=2)cols.forEach(c=>run.push({row:r,col:c}))}});
  flush()}
/* photos with "Role / Name" captions (class officers, staff...) become the same cards as Senate Members */
function peopleGrids(M){
  const blocks=[...M.querySelectorAll(".sqs-block-image,.image-block,figure")].filter(b=>!b.closest(".usg-done,.sm-grid")&&!(b.tagName==="FIGURE"&&b.closest(".sqs-block-image,.image-block")));
  const people=[];blocks.forEach(b=>{const im=b.querySelector("img"),cap=b.querySelector("figcaption,.image-caption,.image-title-wrapper,.image-subtitle-wrapper");if(!cap)return;
    const t=cap.cloneNode(true);t.querySelectorAll("br").forEach(x=>x.replaceWith("\n"));t.querySelectorAll("p,div,span.role,span.name").forEach(x=>x.append("\n"));
    const parts=t.textContent.split("\n").map(x=>x.trim()).filter(Boolean);if(parts.length<2||parts.length>4||parts.join(" ").length>110)return;
    if(/[.!?]$/.test(parts[0])||parts[0].split(" ").length>7)return;
    people.push({b,m:im?imgSrc(im):"",role:tc(parts[0]),name:tc(parts.slice(1).join(" "))})});
  if(people.length<2)return;
  const uses={};people.forEach(p=>{if(p.m)uses[p.m]=(uses[p.m]||0)+1});
  const heads=[...M.querySelectorAll("h1,h2,h3,h4")];
  const groupOf=p=>{let h=null;heads.forEach(x=>{if(x.compareDocumentPosition(p.b)&Node.DOCUMENT_POSITION_FOLLOWING)h=x});return h};
  const groups=new Map();people.forEach(p=>{const g=groupOf(p);if(!groups.has(g))groups.set(g,[]);groups.get(g).push(p)});
  groups.forEach(list=>{const grid=document.createElement("div");grid.className="sm-grid sm-inpage";
    list.forEach(p=>{p.placeholder=!p.m||uses[p.m]>=3;grid.insertAdjacentHTML("beforeend",personCard(p,false))});
    const first=list[0].b,host=first.closest(".sqs-row,.row")||first;host.parentNode.insertBefore(grid,host);
    list.forEach(p=>{const blk=p.b.closest(".sqs-block")||p.b;blk.remove()})});
  M.querySelectorAll(".sqs-col,[class*='sqs-col-'],.sqs-row,.row").forEach(c=>{if(!c.textContent.trim()&&!c.querySelector("img,iframe,form,video,.flip,.sm-grid"))c.remove()})}

/* ---------- events (from the Squarespace Events page) ---------- */
let EVENTS=[],evView="wall",showPast=false,mCur=(()=>{const{iso}=nowNJ();return{y:+iso.slice(0,4),m:+iso.slice(5,7)-1}})();
function poster(e,i){const r=[-2.2,1.6,-1,2.4,-1.8,1][i%6];
  return `<a class="poster" href="${esc(e.url||"/events-calendar")}" style="--r:${r}deg"><span class="date"><span><small>${MON[+e.date.slice(5,7)-1].toUpperCase()}</small><b class="xw">${+e.date.slice(8)}</b></span></span>
  <div class="paper"><span class="tape"></span>${e.image?`<img src="${esc(e.image)}" alt="" loading="lazy">`:`<div class="typeposter"><b class="xw">${esc(e.title)}</b></div>`}</div>
  <h3 class="xw" style="font-variation-settings:'wdth' 100">${esc(e.title)}</h3><div class="meta">${esc(e.start?fmtTime(e.start):"")}${e.start&&e.location?", ":""}${esc(e.location||"")}</div></a>`}
function renderMonth(out){const{y,m}=mCur,today=nowNJ().iso,first=new Date(Date.UTC(y,m,1)).getUTCDay(),dim=new Date(Date.UTC(y,m+1,0)).getUTCDate();let cells="";
  for(let i=0;i<Math.ceil((first+dim)/7)*7;i++){const dt=new Date(Date.UTC(y,m,i-first+1)),iso=dt.toISOString().slice(0,10),o=dt.getUTCMonth()!==m;
    cells+=`<div class="day${o?" out":""}${iso===today?" today":""}"><span class="n">${dt.getUTCDate()}</span>${EVENTS.filter(e=>e.date===iso).map(e=>`<a class="chip" href="${esc(e.url||"#")}" title="${esc(e.title)}">${esc(e.start?fmtTime(e.start)+" ":"")}${esc(e.title)}</a>`).join("")}</div>`}
  out.innerHTML=`<div class="month"><div class="mhead"><button type="button" class="mP" aria-label="Previous month">‹</button><h3 class="xw">${MONL[m]} ${y}</h3><button type="button" class="mN" aria-label="Next month">›</button></div><div class="grid7">${DAYS.map(d=>`<div class="dow">${d}</div>`).join("")}${cells}</div></div>`;
  out.querySelector(".mP").onclick=()=>{mCur=m?{y,m:m-1}:{y:y-1,m:11};renderEvents()};out.querySelector(".mN").onclick=()=>{mCur=m<11?{y,m:m+1}:{y:y+1,m:0};renderEvents()}}
function renderEvents(){const cutoff=daysAgo(7),live=EVENTS.filter(e=>(e.endDate||e.date)>=cutoff),old=EVENTS.filter(e=>(e.endDate||e.date)<cutoff).reverse();
  const homeSec=$("#events");if(homeSec)homeSec.hidden=!live.length;
  const today=nowNJ().iso;const up=live.slice(0,8);
  const items=up.length?up.map(e=>`${MON[+e.date.slice(5,7)-1]} ${+e.date.slice(8)} ${e.title}${e.location?" @ "+e.location:""}`):["Frist 204 is open seven days a week","Tea, coffee, and snacks on us","Questions? usg@princeton.edu","Serve. Represent. Advocate."];
  const h=items.map(t=>`<span>${esc(t)}</span>`).join("");$("#track").innerHTML=h+h;
  $$(".evOut").forEach(out=>{if(!out.offsetParent&&out.id!=="evOut")return;const onPage=out.id!=="evOut";
    if(evView==="month"&&onPage){renderMonth(out);return}
    const list=onPage&&showPast?[...live,...old]:live;
    out.innerHTML=(list.length?`<div class="wall">${list.map(poster).join("")}</div>`:`<div class="empty"><h3 class="xw">Nothing coming up</h3><p>New events land here as soon as they’re announced.</p></div>`)
      +(onPage&&old.length?`<button class="pastbtn" data-past>${showPast?"Hide the archive":"Event archive ("+old.length+")"}</button>`:"");
    out.querySelectorAll("[data-past]").forEach(b=>b.onclick=()=>{showPast=!showPast;renderEvents()});afterRender(out)})}

/* ---------- committees ---------- */
let CHAIRPHOTO={},CBODY={},CHAIRNAME={},PHOTOBYNAME={},chairLoad=null;
const chairOf=c=>(CHAIRNAME[c.slug]&&CHAIRNAME[c.slug].length?CHAIRNAME[c.slug].join(" & "):c.chair);
const ROLE2C=[["academic","academics"],["campus","campus-community-affairs"],["diversity","dei"],["mental","mental-health"],["social","social"],["sustainab","sustainability"],["student life","university-student-life"]];
/* bubble lettering: a display face matched to each topic, chair names "signed" in a brush script */
const FONT_URL="https://fonts.googleapis.com/css2?family=Big+Shoulders+Display:wght@900&family=Bowlby+One&family=Bungee&family=Cinzel:wght@900&family=DM+Serif+Display&family=Fredoka:wght@700&family=Gluten:wght@800&family=Graduate&family=IM+Fell+English+SC&family=Lilita+One&family=Lobster&family=Mr+Dafoe&family=Righteous&family=Shrikhand&display=swap";
function loadBubbleFonts(){if(document.querySelector('link[data-usg-bubble-fonts]'))return;const l=document.createElement("link");l.rel="stylesheet";l.href=FONT_URL;l.dataset.usgBubbleFonts=1;document.head.appendChild(l)}
const TOPIC_FONTS=[
 [/^academ|curricul|course|advising/i,{f:"'DM Serif Display',Georgia,serif",s:1.08,t:"none",ls:"0"}],
 [/campus|community affairs/i,{f:"'Lilita One',system-ui,sans-serif",s:1.02,t:"none",ls:".01em"}],
 [/divers|equity|inclusion/i,{f:"'Shrikhand',Georgia,serif",s:.98,t:"none",ls:"0"}],
 [/mental|wellness|health/i,{f:"'Fredoka',system-ui,sans-serif",s:1.08,t:"none",ls:"0"}],
 [/sustainab|climate|environment|green/i,{f:"'Gluten',system-ui,sans-serif",s:1.02,t:"none",ls:"0"}],
 [/student life|housing|dorm|residential/i,{f:"'Bowlby One',Impact,sans-serif",s:.9,t:"none",ls:".01em"}],
 [/^social|event|party/i,{f:"'Bungee',Impact,sans-serif",s:.92,t:"uppercase",ls:".02em"}],
 [/athlet|sport|recreation|fitness/i,{f:"'Graduate',Georgia,serif",s:.98,t:"uppercase",ls:".02em"}],
 [/civil|libert|rights|speech|justice/i,{f:"'IM Fell English SC',Georgia,serif",s:1.08,t:"none",ls:".01em"}],
 [/dining|food|meal/i,{f:"'Lobster',Georgia,cursive",s:1.18,t:"none",ls:"0"}],
 [/international|global|abroad/i,{f:"'Righteous',system-ui,sans-serif",s:.98,t:"none",ls:".01em"}],
 [/relig|faith|spiritual|interfaith/i,{f:"'Cinzel',Georgia,serif",s:.96,t:"uppercase",ls:".03em"}],
 [/transit|transport|\bbus\b|travel|commut/i,{f:"'Big Shoulders Display',Impact,sans-serif",s:1.18,t:"uppercase",ls:".03em"}],
 [/arts?\b|music|theat|culture/i,{f:"'Shrikhand',Georgia,serif",s:.98,t:"none",ls:"0"}]];
const fontFor=name=>{const hit=TOPIC_FONTS.find(([re])=>re.test(name));return hit?hit[1]:{f:"inherit",s:1,t:"none",ls:"0"}};
function orbitHTML(items,label){loadBubbleFonts();const n=items.length;
  const bubs=items.map((c,i)=>{const th=c.theme,ang=-90+i*360/n,sz=[1,.86,.94,.82,.98,.88,.9][i%7];
    const ft=fontFor(c.name);
    return `<a class="bub" href="${c.href}" style="--acc:${th.acc};--acc2:${th.acc2};--ang:${ang}deg;--sz:${sz};--dl:${(i*0.7).toFixed(1)}s;--bf:${ft.f.replace(/"/g,"'")};--bs:${ft.s};--bt:${ft.t};--bl:${ft.ls}"><span class="bub-in"><span class="bub-claw" aria-hidden="true"><i></i><i></i><i></i></span><span class="bub-stk">${stickerSVG(th.st[0])}</span><b>${esc(c.name)}</b>${c.sub?`<small>${esc(c.sub)}</small>`:""}</span></a>`}).join("");
  return `<div class="orbit"><div class="orbit-hub"><img src="${esc(LOGO)}" alt=""><b>${esc(label)}</b></div>${bubs}</div>`}
/* index pages (Committees, Working Groups): intro + quick links on the left, bubble ring on the right */
function indexLayout(out,M,items,orbit,label,fallback){
  M.querySelectorAll("h1,h2,h3").forEach(h=>{h.textContent=h.textContent.replace(/^\s+/,"").replace(/:\s*$/,"")});
  const grid=document.createElement("div");grid.className="cm-index";
  const left=document.createElement("div");left.className="cm-index-text";
  const intro=wrapProse(M);if(M.textContent.trim())left.appendChild(intro);else left.innerHTML=`<div class="prose"><p>${esc(fallback)}</p></div>`;
  left.insertAdjacentHTML("beforeend",`<p class="cm-hint">${esc(label)}</p><nav class="cm-chips">${items.map(c=>`<a href="${c.href}" style="--acc:${c.theme.acc}"><i></i>${esc(c.name)}</a>`).join("")}</nav>`);
  const right=document.createElement("div");right.className="cm-index-orbit";right.innerHTML=orbit;
  grid.appendChild(left);grid.appendChild(right);out.appendChild(grid);prep(M)}
function cardsHTML(){return orbitHTML(COMMITTEES.map(c=>({href:"/committees#c-"+c.slug,name:c.name,sub:chairOf(c),theme:THEMES[c.slug]})),COMMITTEES.length+" committees")}
function flatBlocks(root){return [...root.querySelectorAll("h1,h2,h3,h4,p,ul,ol,blockquote,figure")].filter(e=>!e.parentElement.closest("ul,ol,blockquote,p,figure"))}
function committeeSections(root){stripCode(root);const els=flatBlocks(root),out={},used=[];
  COMMITTEES.forEach(c=>{const i=els.findIndex(e=>/^H[1-4]$/.test(e.tagName)&&/committee/i.test(e.textContent)&&c.match.some(k=>e.textContent.toLowerCase().includes(k)));if(i<0)return;
    const lvl=+els[i].tagName[1],parts=[];used.push(els[i]);for(let k=i+1;k<els.length;k++){const e=els[k];if(/^H[1-4]$/.test(e.tagName)&&+e.tagName[1]<=lvl)break;parts.push(e.cloneNode(true));used.push(e)}
    out[c.slug]=parts});
  Object.defineProperty(out,"_used",{value:used,enumerable:false});return out}
/* Chair names and photos come from the Senate Members page, matched by role ("Academics Chair", "Chair of Social", ...) */
function loadChairPhotos(){if(chairLoad)return chairLoad;chairLoad=(async()=>{try{const j=await sqJSON("/senate-members");const d=document.createElement("div");d.innerHTML=j.mainContent||"";
    d.querySelectorAll("figure,.image-block").forEach(f=>{if(f.parentElement.closest("figure"))return;const im=f.querySelector("img");const capEl=f.querySelector("figcaption,.image-caption");if(!capEl)return;
      const tmp=capEl.cloneNode(true);tmp.querySelectorAll("br").forEach(b=>b.replaceWith("\n"));tmp.querySelectorAll("p,div").forEach(p=>p.append("\n"));
      const parts=tmp.textContent.split("\n").map(x=>x.trim()).filter(Boolean);if(parts.length<2)return;
      const role=parts[0].toLowerCase(),name=tc(parts.slice(1).join(" "));if(im&&name)PHOTOBYNAME[name.toLowerCase()]=PHOTOBYNAME[name.toLowerCase()]||sized(imgSrc(im),500);if(!/chair/.test(role))return;
      const hit=ROLE2C.find(([k])=>role.includes(k));if(!hit)return;const slug=hit[1];
      if(im&&!CHAIRPHOTO[slug])CHAIRPHOTO[slug]=sized(imgSrc(im),500);
      CHAIRNAME[slug]=CHAIRNAME[slug]||[];if(name&&!CHAIRNAME[slug].includes(name))CHAIRNAME[slug].push(name)})}catch(e){}})();return chairLoad}
function viewCommittee(slug,src){const c=COMMITTEES.find(x=>x.slug===slug);if(!c)return false;const th=THEMES[slug];
  band([["USG","/"],["Committees","/committees"]],c.name,{narrow:true});$("#bandStk").innerHTML=stickerField(slug,"band");$("#bandStrip").innerHTML=themeStrip(slug);$("#v-inner").style.setProperty("--acc",th.acc);
  const out=$("#innerOut");const parts=CBODY[slug]||[];const body=document.createElement("div");body.className="prose";parts.forEach(p=>body.appendChild(p.cloneNode(true)));
  if(!parts.length)body.innerHTML=`<p>The ${esc(c.name)} Committee is one of the USG Senate’s core committees.</p>`;
  const emails=[...new Set((body.innerHTML.match(/[A-Za-z0-9._-]+@princeton\.edu/gi)||[]).map(x=>x.toLowerCase()))];
  out.innerHTML=`<div class="cm-stickers">${stickerField(slug,"content")}</div><div class="cm-body"><div class="cm-main"></div><aside><div class="side"><h2 class="xw">Chair</h2><div class="chairs"><div class="chair">${CHAIRPHOTO[slug]?`<img class="av" src="${esc(CHAIRPHOTO[slug])}" alt="">`:`<span class="av" aria-hidden="true">${esc(chairOf(c)[0])}</span>`}<div><b>${esc(chairOf(c))}</b>${emails[0]?`<a href="mailto:${esc(emails[0])}">${esc(emails[0])}</a>`:""}</div></div></div></div>
    <div class="side links"><h2 class="xw">More</h2><a href="/committees">All committees</a><a href="/senate-members">Senate members</a></div></aside></div>`;
  out.querySelector(".cm-main").appendChild(body);prep(body);afterRender(out);scrollTo(0,0);return true}

/* ---------- Working Groups: same idea as Committees, built from the page's own sections ---------- */
let WGROUPS=[];
const slugify=t=>t.toLowerCase().replace(/&/g,"and").replace(/[^a-z0-9]+/g,"-").replace(/^-|-$/g,"");
/* stickers + colours chosen from each working group's topic */
Object.assign(STK,{
 ball:c=>`<circle cx="60" cy="60" r="40" fill="${c}" ${K}/><path d="M20 60h80M60 20v80M33 31c15 15 15 43 0 58M87 31c-15 15-15 43 0 58" fill="none" ${K}/>`,
 trophy:c=>`<path d="M38 22h44v22c0 16-10 28-22 28S38 60 38 44Z" fill="${c}" ${K}/><path d="M38 30H24c0 14 6 20 16 22M82 30h14c0 14-6 20-16 22" fill="none" ${K}/><rect x="52" y="72" width="16" height="14" fill="${c}" ${K}/><rect x="36" y="86" width="48" height="12" rx="3" fill="#222" ${K}/>`,
 scales:c=>`<path d="M60 20v72M26 34h68" fill="none" ${K}/><path d="M26 34 13 66M26 34l13 32M94 34 81 66M94 34l13 32" fill="none" ${K}/><path d="M11 66c0 12 30 12 30 0Z" fill="${c}" ${K}/><path d="M79 66c0 12 30 12 30 0Z" fill="${c}" ${K}/><rect x="40" y="92" width="40" height="10" rx="3" fill="#222" ${K}/><circle cx="60" cy="22" r="6" fill="${c}" ${K}/>`,
 megaphone:c=>`<path d="M22 50h18l44-22v64L40 70H22Z" fill="${c}" ${K}/><path d="M30 70l6 22h12l-4-22" fill="#fff" ${K}/><path d="M94 46c6 6 6 22 0 28M102 38c10 12 10 34 0 46" fill="none" ${K}/>`,
 fork:c=>`<path d="M34 18v26c0 9 14 9 14 0V18M41 18v28M41 50v52" fill="none" ${K}/><path d="M74 18c13 6 16 30 5 40v44h-9V18Z" fill="${c}" ${K}/>`,
 plane:c=>`<path d="M60 12c6 0 8 8 8 14v18l34 18v10l-34-8v18l10 8v8l-18-5-18 5v-8l10-8V64l-34 8V62l34-18V26c0-6 2-14 8-14Z" fill="${c}" ${K}/>`,
 dove:c=>`<path d="M18 66c18 0 32-8 42-24 6-10 18-14 26-8l14-2-9 11c3 24-15 43-45 43-10 0-18-4-26-10 10 0 20-4 26-12-8 4-19 4-28 2Z" fill="${c}" ${K}/><circle cx="86" cy="40" r="3" fill="#222"/><path d="M40 62c10 2 22-4 28-14" fill="none" ${K}/>`,
 candle:c=>`<rect x="46" y="52" width="28" height="52" rx="4" fill="${c}" ${K}/><path d="M60 52v-8" fill="none" ${K}/><path d="M60 12c11 13 11 23 0 30-11-7-11-17 0-30Z" fill="#F76707" ${K}/><path d="M60 25c4 6 4 10 0 13-4-3-4-7 0-13Z" fill="#FFD43B"/>`,
 bus:c=>`<rect x="20" y="22" width="80" height="64" rx="12" fill="${c}" ${K}/><rect x="30" y="32" width="60" height="22" rx="4" fill="#D0EBFF" ${K}/><path d="M60 32v22M30 64h60" fill="none" ${K}/><circle cx="36" cy="74" r="5" fill="#fff" ${K}/><circle cx="84" cy="74" r="5" fill="#fff" ${K}/><path d="M30 86v12h14V86M76 86v12h14V86" fill="#222" ${K}/>`});
const GROUP_THEMES=[
 [/athlet|sport|recreation|\bgames?\b|fitness/i,{acc:"#F76707",acc2:"#FFD43B",st:[["ball","#F76707"],["trophy","#FCC419"]]}],
 [/civil|libert|rights|speech|justice|free expression/i,{acc:"#364FC7",acc2:"#FCC419",st:[["scales","#FCC419"],["megaphone","#E03131"]]}],
 [/dining|food|meal|nutrition/i,{acc:"#E03131",acc2:"#FFD43B",st:[["fork","#FFD43B"],["pizza","#E03131"]]}],
 [/international|global|abroad|visa/i,{acc:"#1098AD",acc2:"#FFD43B",st:[["plane","#4DABF7"],["globe","#69DB7C"]]}],
 [/relig|faith|spiritual|interfaith/i,{acc:"#7048E8",acc2:"#FFD43B",st:[["dove","#FFFFFF"],["candle","#FFD43B"]]}],
 [/transit|transport|\bbus\b|tigertransit|travel|commut/i,{acc:"#2B8A3E",acc2:"#FFD43B",st:[["bus","#FCC419"],["pin","#F58025"]]}],
 [/housing|dorm|residential/i,{acc:"#C2255C",acc2:"#FFD43B",st:[["house","#FFA8A8"],["key","#FAB005"]]}],
 [/health|wellness|mental/i,{acc:"#0CA678",acc2:"#FFA8A8",st:[["heart","#FF8787"],["sun","#FFD43B"]]}],
 [/sustainab|climate|environment|green/i,{acc:"#2B8A3E",acc2:"#A9E34B",st:[["leaf","#51CF66"],["recycle","#2B8A3E"]]}],
 [/academ|curricul|course|advising/i,{acc:"#3B5BDB",acc2:"#FCC419",st:[["book","#4DABF7"],["cap","#3B5BDB"]]}],
 [/arts?\b|music|theat|culture/i,{acc:"#D6336C",acc2:"#FFD43B",st:[["note","#FFD43B"],["disco","#F06595"]]}],
 [/divers|equity|inclusion|access|first.gen|fli/i,{acc:"#9C36B5",acc2:"#FF8787",st:[["heart","#F06595"],["venn","#CC5DE8"]]}],
 [/social|event|party/i,{acc:"#E8590C",acc2:"#7048E8",st:[["popper","#7048E8"],["ticket","#7048E8","EVENT"]]}]];
const GROUP_FALLBACK=[{acc:"#5F3DC4",st:[["bubble","#FFEC99","ideas?"]]},{acc:"#1971C2",st:[["bubble","#FFEC99","join us!"]]},{acc:"#E67700",st:[["badge","#FFFFFF","USG|working group"]]}];
function groupTheme(name,i){const hit=GROUP_THEMES.find(([re])=>re.test(name));const t=hit?hit[1]:GROUP_FALLBACK[i%GROUP_FALLBACK.length];return{acc:t.acc,acc2:t.acc2||"#FFD43B",st:t.st,words:[]}}

/* Working groups are found by their "Mission" sub-heading: the group's name is the heading (any size)
   or bold title just above it. Fallback: the most-used heading size that isn't Mission/Priorities. */
function parseGroups(M){stripCode(M);
  M.querySelectorAll("h1,h2,h3,h4,h5,h6,p,li").forEach(e=>{if(!/chairs?\s*\(\s*\)/i.test(e.textContent.replace(/\u00a0/g," ")))return;
    e.innerHTML=e.innerHTML.replace(/contact(?:\s|&nbsp;)*(?:<[^>]*>)*\s*chairs?(?:\s|&nbsp;|<[^>]*>)*\((?:\s|&nbsp;|<[^>]*>)*\)/i,'contact <a href="mailto:usg@princeton.edu">usg@princeton.edu</a>')});
  const els=[...M.querySelectorAll("h1,h2,h3,h4,h5,h6,p,ul,ol,blockquote,figure,hr")].filter(e=>!e.parentElement.closest("ul,ol,blockquote,p,figure"));
  const isH=e=>/^H[1-6]$/.test(e.tagName);
  const SUB=/^(mission|priorities|goals?|initiatives|members?|contact|get involved|meeting|chairs?)\b/i;
  const txt=e=>e.textContent.replace(/\s+/g," ").trim();
  const isTitleP=e=>e.tagName==="P"&&txt(e).length>1&&txt(e).length<70&&(()=>{const b=e.querySelector("strong,b");return b&&txt(b)===txt(e)})();
  const isName=e=>(isH(e)||isTitleP(e))&&!SUB.test(txt(e).replace(/[:\s]+$/,""))&&!/^about\b|working groups?:?$/i.test(txt(e));
  let heads=[];
  const anchors=els.filter(e=>(isH(e)||isTitleP(e))&&/^mission\b/i.test(txt(e)));
  if(anchors.length>=1){anchors.forEach(a=>{for(let i=els.indexOf(a)-1;i>=0;i--){const e=els[i];if(isName(e)){if(!heads.includes(e))heads.push(e);break}if(heads.includes(e))break}})}
  if(heads.length<2){for(const n of [1,2,3,4]){const hs=els.filter(e=>e.tagName==="H"+n&&isName(e));if(hs.length>=2){heads=hs;break}}}
  heads.sort((a,b)=>a.compareDocumentPosition(b)&Node.DOCUMENT_POSITION_FOLLOWING?-1:1);
  const out=[];
  heads.forEach((h,k)=>{const name=txt(h).replace(/:\s*$/,"");const start=els.indexOf(h),end=k+1<heads.length?els.indexOf(heads[k+1]):els.length;
    const parts=els.slice(start+1,end).filter(e=>e.tagName!=="HR");
    const text=parts.map(e=>e.textContent).join(" ");const ms=[...text.matchAll(/\bchairs?\s+([A-Z][^()\n,]+?)\s*(?:\(|,|\.|$)/gi)],m=ms[ms.length-1];const em=(text.match(/[A-Za-z0-9._-]+@princeton\.edu/i)||[])[0];
    out.push({slug:slugify(name),name,head:h,parts,chair:m?m[1].trim():"",email:em||""})});
  out.forEach((g,i)=>g.theme=groupTheme(g.name,i));return out}
function viewGroup(slug){const g=WGROUPS.find(x=>x.slug===slug);if(!g)return false;
  band([["USG","/"],["Working groups","/workinggroups"]],g.name,{narrow:true});
  const out=$("#innerOut");const body=document.createElement("div");body.className="prose";g.parts.forEach(p=>body.appendChild(p.cloneNode(true)));
  const photo=g.chair&&PHOTOBYNAME[g.chair.toLowerCase()];
  out.innerHTML=`<div class="cm-body"><div class="cm-main"></div><aside>${g.chair?`<div class="side"><h2 class="xw">Chair</h2><div class="chairs"><div class="chair">${photo?`<img class="av" src="${esc(photo)}" alt="">`:`<span class="av" aria-hidden="true">${esc(g.chair[0])}</span>`}<div><b>${esc(g.chair)}</b>${g.email?`<a href="mailto:${esc(g.email)}">${esc(g.email)}</a>`:""}</div></div></div></div>`:""}
    <div class="side links"><h2 class="xw">More</h2><a href="/workinggroups">All working groups</a><a href="/committees">Committees</a></div></aside></div>`;
  out.querySelector(".cm-main").appendChild(body);prep(body);afterRender(out);scrollTo(0,0);return true}
async function pageGroups(M){WGROUPS=parseGroups(M);await loadChairPhotos();
  const show=()=>{const h=location.hash.slice(1);clearTheme();if(h.startsWith("w-")&&viewGroup(h.slice(2)))return;
    band([["USG","/"],["Get involved"]],"Working Groups");const out=$("#innerOut");out.innerHTML="";
    if(!M._trimmed){WGROUPS.forEach(g=>{[g.head,...g.parts].forEach(e=>{if(!e||!e.parentNode)return;const blk=e.closest(".sqs-block");e.remove();if(blk&&!blk.textContent.trim()&&!blk.querySelector("img,iframe,form"))blk.remove()})});M.querySelectorAll("hr").forEach(h=>h.remove());M._trimmed=true}
    const items=WGROUPS.map(g=>({href:"/workinggroups#w-"+g.slug,name:g.name,sub:g.chair,theme:g.theme}));
    indexLayout(out,M,items,WGROUPS.length?orbitHTML(items,WGROUPS.length+" working groups"):"","Jump to a working group","USG Working Groups are flexible, issue-focused teams established each semester.");afterRender(out);scrollTo(0,0)};
  addEventListener("hashchange",show);show()}

/* ---------- Senate Members ---------- */
const tc=s=>String(s||"").replace(/U-\s+/gi,"U-").toLowerCase().replace(/(^|[\s\-'’(/&])(\p{L})/gu,(m,a,b)=>a+b.toUpperCase()).replace(/\bMc(\p{L})/gu,(m,b)=>"Mc"+b.toUpperCase()).replace(/\bU-c/g,"U-C").replace(/\b(And|Of|The|For)\b/g,w=>w.toLowerCase()).replace(/\bUsg\b/g,"USG").replace(/\bSgrc\b/g,"SGRC").replace(/\bDei\b/g,"DEI").replace(/\bCpuc\b/g,"CPUC").replace(/\bExcomm\b/g,"ExComm");
function personCard(p,big){const th=p.committee&&THEMES[p.committee];const tag=p.committee?"a":"div";
    return `<${tag} class="sm${big?" sm-big":""}${p.placeholder?" sm-none":""}"${p.committee?` href="/committees#c-${p.committee}"`:""}${th?` style="--acc:${th.acc}"`:""} data-q="${esc((p.name+" "+p.role).toLowerCase())}">
      <div class="sm-ph">${p.placeholder?`<img class="sm-logo" src="${esc(LOGO)}" alt="Princeton USG">`:`<img src="${esc(sized(p.m,600))}" alt="${esc(p.name)}" loading="lazy">`}${th?`<span class="sm-stk">${stickerSVG(th.st[0])}</span>`:""}</div>
      <div class="sm-tx"><span class="sm-role">${esc(p.role)}</span><b class="sm-name">${esc(p.name)}</b>${p.committee?`<span class="sm-go">Committee page →</span>`:""}</div></${tag}>`}
function viewSenate(M){const secs=[];let cur=null;
  flatBlocks(M).forEach(el=>{if(/^H[1-4]$/.test(el.tagName)){if(el.textContent.trim()){cur={title:tc(el.textContent.trim()),people:[]};secs.push(cur)}return}
    if(el.tagName!=="FIGURE")return;const im=el.querySelector("img");if(!im)return;if(!cur){cur={title:"Members",people:[]};secs.push(cur)}
    const parts=capLines(el.querySelector("figcaption,.image-caption"));
    cur.people.push({m:imgSrc(im),role:tc(parts.length>1?parts[0]:""),name:tc(parts.length>1?parts.slice(1).join(" "):parts[0]||"")})});
  const list=secs.filter(s=>s.people.length);if(!list.length)return false;
  const uses={};list.forEach(s=>s.people.forEach(p=>{if(p.m)uses[p.m]=(uses[p.m]||0)+1}));
  list.forEach(s=>s.people.forEach(p=>{p.placeholder=!p.m||uses[p.m]>=3;if(/committee/i.test(s.title)){const hit=ROLE2C.find(([k])=>p.role.toLowerCase().includes(k));if(hit)p.committee=hit[1]}}));
  band([["USG","/"],["Senate"]],"Senate Members");
  const slug=t=>t.toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/^-|-$/g,"");
  const card=personCard;
  const out=$("#innerOut");
  out.innerHTML=`<div class="sm-bar"><nav class="sm-nav" aria-label="Sections">${list.map(s=>`<a href="#" data-jump="${slug(s.title)}">${esc(s.title)} <small>${s.people.length}</small></a>`).join("")}</nav>
      <label class="sm-search"><span class="sr">Find a member</span><input type="search" id="smQ" placeholder="Find a name or role"></label></div>
    ${list.map((s,si)=>`<section class="sm-sec" id="sec-${slug(s.title)}"><div class="sm-head"><h2 class="xw">${esc(s.title)}</h2><span class="sm-count">${s.people.length}</span></div><div class="sm-grid${si===0?" sm-exec":""}">${s.people.map((p,i)=>card(p,si===0&&i<2)).join("")}</div></section>`).join("")}
    <p class="sm-empty" id="smNone" hidden>No one matches that search.</p>`;
  out.querySelectorAll("[data-jump]").forEach(a=>a.onclick=e=>{e.preventDefault();const t=$("#sec-"+a.dataset.jump);if(t)scrollTo({top:t.getBoundingClientRect().top+scrollY-150,behavior:RM?"auto":"smooth"})});
  $("#smQ").oninput=e=>{const q=e.target.value.trim().toLowerCase();let any=false;out.querySelectorAll(".sm-sec").forEach(sec=>{let n=0;sec.querySelectorAll(".sm").forEach(c=>{const ok=!q||c.dataset.q.includes(q);c.hidden=!ok;if(ok)n++});sec.hidden=!n;if(n)any=true});$("#smNone").hidden=any};
  afterRender(out);return true}

/* ---------- video band (YouTube plays normally on the real site) ---------- */
/* Squarespace's own banner / section-background video: pull its stream URLs out of whatever markup the template uses */
let SQV=null;
function sqsVideo(){if(SQV)return SQV;const root=document.getElementById("usg-root");const found={hls:"",mp4:"",yt:"",vimeo:""};
  const els=[...document.querySelectorAll('[class*="video-background"],[class*="videoBackground"],.section-background,.banner-thumbnail-wrapper,[data-config-video],[data-config-native-video],[data-config-url],[data-video-url],video[src*="squarespace"],video source[src*="squarespace"]')].filter(e=>!(root&&root.contains(e)));
  els.forEach(e=>{const html=e.outerHTML.replace(/&quot;/g,'"').replace(/&amp;/g,"&").replace(/\\\//g,"/");
    const h=html.match(/https?:\/\/[^"'\s<>]+?\.m3u8[^"'\s<>]*/i);if(h&&!found.hls)found.hls=h[0];
    const m=html.match(/https?:\/\/[^"'\s<>]+?\.mp4[^"'\s<>]*/i);if(m&&!found.mp4)found.mp4=m[0];
    const vm=html.match(/vimeo\.com\/(?:video\/)?(\d{5,})/);if(vm&&!found.vimeo)found.vimeo=vm[1];
    const y=html.match(/(?:youtube\.com\/(?:watch\?v=|embed\/)|youtu\.be\/)([\w-]{11})/);if(y&&!found.yt)found.yt=y[1]});
  return found}
function renderVideo(){const bg=$("#heroBg");if(!bg)return;const reel=bg.closest(".reel");
  /* "reduce motion": the band stays, showing the still frame; no video is loaded */
  if(RM){reel.classList.add("video-on","vid-ready","vid-still");if(VIDEO.poster)reel.style.setProperty("--reel-still",`url("${VIDEO.poster}")`);sizePins();return}
  const on=()=>{reel.classList.add("vid-ready");sizePins();requestTick()};
  /* hold the band's space from the start, so the page below never shifts when the video arrives */
  reel.classList.add("video-on");
  if(VIDEO.poster)reel.style.setProperty("--reel-still",`url("${VIDEO.poster}")`);
  /* 1st choice: the video file uploaded to Squarespace (same site, always autoplays). 2nd: YouTube, forced to play muted. */
  const tryFile=()=>new Promise(res=>{if(!VIDEO.file&&!sqsVideo().hls&&!sqsVideo().mp4)return res(false);const v=document.createElement("video");
    v.muted=true;v.defaultMuted=true;v.setAttribute("muted","");v.autoplay=true;v.loop=true;v.playsInline=true;v.setAttribute("playsinline","");v.setAttribute("webkit-playsinline","");
    v.preload="auto";if(VIDEO.poster)v.poster=VIDEO.poster;v.disablePictureInPicture=true;v.setAttribute("disableremoteplayback","");v.controls=false;
    let settled=false;const done=ok=>{if(!settled){settled=true;res(ok)}};
    const play=()=>{const p=v.play();if(p&&p.catch)p.catch(()=>{if(v.paused)reel.classList.remove("vid-playing")})};
    v.addEventListener("playing",()=>reel.classList.add("vid-playing"));
    v.addEventListener("pause",()=>reel.classList.remove("vid-playing"));
    if(VIDEO.poster)reel.style.setProperty("--reel-still",`url("${VIDEO.poster}")`);
    /* show the band as soon as the file starts arriving; only a missing/broken file falls back to YouTube */
    v.addEventListener("loadedmetadata",()=>{if(!v.isConnected){bg.innerHTML="";bg.appendChild(v)}on();play();done(true)},{once:true});
    v.addEventListener("canplay",play);v.addEventListener("pause",()=>{if(!document.hidden)setTimeout(play,300)});
    v.addEventListener("error",()=>done(false),{once:true});
    new IntersectionObserver(es=>es.forEach(e=>e.isIntersecting&&play()),{threshold:.05}).observe(reel);
    ["pointerdown","touchstart","touchend","click","scroll","keydown"].forEach(t=>addEventListener(t,play,{passive:true,capture:true}));
    document.addEventListener("visibilitychange",()=>{if(!document.hidden)play()});
    /* phones get the small file; if a phone still blocks autoplay (e.g. Low Power Mode) the still frame shows, never a play button, and it starts on the first tap */
    const small=matchMedia("(max-width:900px)").matches||matchMedia("(pointer:coarse)").matches;
    const sq=sqsVideo();const hlsOK=!!v.canPlayType("application/vnd.apple.mpegurl");
    v.src=asset((sq.hls&&hlsOK&&sq.hls)||sq.mp4||(small&&VIDEO.phone)||VIDEO.file);v.load()});
  /* the band streams the same YouTube embed as the Squarespace banner, shown only once the player says it is actually playing */
  const youtube=id=>{bg.innerHTML=`<iframe src="https://www.youtube.com/embed/${id}?autoplay=1&mute=1&loop=1&playlist=${id}&controls=0&rel=0&playsinline=1&disablekb=1&iv_load_policy=3&modestbranding=1&fs=0&enablejsapi=1&origin=${encodeURIComponent(location.origin)}" title="" tabindex="-1" allow="autoplay; encrypted-media; picture-in-picture" referrerpolicy="strict-origin-when-cross-origin"></iframe>`;on();
    const f=bg.querySelector("iframe");const send=o=>{try{f.contentWindow.postMessage(JSON.stringify(o),"*")}catch(e){}};
    const nudge=()=>{send({event:"listening",id:1,channel:"widget"});send({event:"command",func:"mute",args:[]});send({event:"command",func:"playVideo",args:[]})};
    f.addEventListener("load",()=>{nudge();let n=0;const t=setInterval(()=>{nudge();if(++n>20)clearInterval(t)},700)});
    new IntersectionObserver(es=>es.forEach(e=>e.isIntersecting&&nudge()),{threshold:.05}).observe(reel);
    ["pointerdown","touchend","click"].forEach(t=>addEventListener(t,nudge,{passive:true,capture:true}));
    addEventListener("message",e=>{let h="";try{h=new URL(e.origin).hostname}catch(x){}if(!/(^|\.)youtube(-nocookie)?\.com$/.test(h))return;
      let d=e.data;try{if(typeof d==="string")d=JSON.parse(d)}catch(x){return}if(!d)return;
      const st=d.event==="onStateChange"?d.info:(d.event==="infoDelivery"&&d.info&&"playerState" in d.info?d.info.playerState:null);
      if(st===1)reel.classList.add("vid-playing");else if(st===0||st===2||st===-1)reel.classList.remove("vid-playing")})};
  const vimeo=id=>{bg.innerHTML=`<iframe src="https://player.vimeo.com/video/${id}?background=1&autoplay=1&muted=1&loop=1&playsinline=1&dnt=1" title="" tabindex="-1" allow="autoplay; fullscreen; picture-in-picture"></iframe>`;on();
    const f=bg.querySelector("iframe");const post=o=>{try{f.contentWindow.postMessage(JSON.stringify(o),"*")}catch(e){}};
    f.addEventListener("load",()=>["play","playProgress","pause"].forEach(v=>post({method:"addEventListener",value:v})));
    ["pointerdown","touchend","click"].forEach(t=>addEventListener(t,()=>post({method:"play"}),{passive:true,capture:true}));
    addEventListener("message",e=>{if(!/vimeo\.com$/.test((()=>{try{return new URL(e.origin).hostname}catch(x){return""}})()))return;let d=e.data;try{if(typeof d==="string")d=JSON.parse(d)}catch(x){return}
      if(d&&(d.event==="play"||d.event==="playProgress"))reel.classList.add("vid-playing");if(d&&d.event==="pause")reel.classList.remove("vid-playing")})};
  /* 1st: the video chosen in the Squarespace banner. Then uploaded video files. Last: the built-in YouTube fallback. */
  /* "reduce motion" is on: keep the still frame, load no video at all */
  if(matchMedia("(prefers-reduced-motion: reduce)").matches){reel.classList.add("vid-still");return}
  const sq=sqsVideo();
  if(sq.yt){youtube(sq.yt);return}
  if(sq.vimeo){vimeo(sq.vimeo);return}
  tryFile().then(ok=>{if(ok)return;if(VIDEO.youtube)youtube(VIDEO.youtube);else reel.classList.remove("video-on")})}

/* ---------- pages ---------- */
function parsePriorities(M){const els=flatBlocks(M);const i=els.findIndex(e=>/^H[1-4]$/.test(e.tagName)&&/priorit/i.test(e.textContent));if(i<0)return null;
  const list=els.slice(i+1).find(e=>e.tagName==="UL"||e.tagName==="OL");if(!list)return null;
  const out=[...list.children].map(li=>{const h=li.querySelector("h1,h2,h3,h4");if(!h)return null;const items=[...li.querySelectorAll("p")].map(p=>p.textContent.trim()).filter(Boolean);return[h.textContent.trim(),items]}).filter(Boolean);
  return out.length>=3?out:null}
const IG_URL="https://www.instagram.com/princeton_usg/",IG_CHANNEL="https://www.instagram.com/channel/roUr63fcnMk0VYgA/";
const IG_ICON='<svg viewBox="0 0 24 24" aria-hidden="true" width="22" height="22"><rect x="3" y="3" width="18" height="18" rx="5" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="12" cy="12" r="4.2" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="17.3" cy="6.7" r="1.3" fill="currentColor"/></svg>';
/* "Latest from USG": links on the left, a tidy square grid of however many posts the Instagram block gives (rounded to full rows) on the right */
function latestLayout(sec,wall,posts){const n=posts.length>=3?Math.min(posts.length-(posts.length%3),12):posts.length;const list=posts.slice(0,n);
  const tools=sec.querySelector(".sh .ev-tools");if(tools)tools.remove();
  const split=document.createElement("div");split.className="ig-split";
  split.innerHTML=`<aside class="ig-side"><p class="ig-lead">Event recaps, announcements and what the Senate is working on, straight from our Instagram.</p>
    <a class="ig-big" href="${IG_URL}" target="_blank" rel="noopener">${IG_ICON}<span><small>Follow us</small>@princeton_usg</span></a>
    <a class="link-solo" href="${IG_CHANNEL}" target="_blank" rel="noopener">Join our Instagram channel</a>
    <a class="ig-mail" href="mailto:usg@princeton.edu"><small>Email us</small>usg@princeton.edu</a></aside>
    <div class="ig-grid2">${list.map(p=>`<a class="ig-tile" href="${esc(p.url)}" target="_blank" rel="noopener"><img src="${esc(p.img)}" alt="${esc(p.cap.slice(0,140)||"Instagram post")}" loading="lazy">${p.cap?`<span class="ig-cap">${esc(p.cap.length>110?p.cap.slice(0,108)+"…":p.cap)}</span>`:""}</a>`).join("")}</div>`;
  wall.replaceWith(split);split.id="latestWall";sec.hidden=false}
/* posts from Squarespace's built-in Instagram block: image, caption and link to the post */
function instagramPosts(ig){const out=[],seen=new Set();
  ig.querySelectorAll("a[href*='instagram.com'],.slide,.sqs-gallery-design-grid-slide,li,figure").forEach(el=>{const a=el.tagName==="A"?el:el.querySelector("a[href*='instagram.com']")||el.closest("a[href*='instagram.com']");
    const im=el.querySelector("img")||(a&&a.querySelector("img"));if(!im)return;const src=imgSrc(im);if(!src||seen.has(src))return;seen.add(src);
    let cap=(a&&(a.dataset.title||a.dataset.description||a.getAttribute("title")))||im.getAttribute("alt")||"";const t=document.createElement("div");t.innerHTML=cap;cap=t.textContent.trim();
    if(/\.(jpe?g|png|webp)$/i.test(cap))cap="";
    out.push({img:sized(src,750),url:a?a.href:"https://www.instagram.com/princeton_usg/",cap})});
  return out}
async function pageHome(M){$("#v-home").hidden=false;$("#v-inner").hidden=true;
  /* a video file linked anywhere on the homepage (Squarespace "link to file") becomes the video band */
  /* a file with "phone" in its name is the small version used on phones; any other video file is the main one */
  [...M.querySelectorAll("a[href]")].filter(a=>/\.(mp4|webm|mov)(\?|#|$)/i.test(a.getAttribute("href"))).forEach(vlink=>{const h=vlink.getAttribute("href");
    if(/phone|mobile/i.test(h))VIDEO.phone=h;else VIDEO.file=h;const blk=vlink.closest(".sqs-block");(blk&&blk.textContent.trim().length<80?blk:vlink).remove()});
  const pr=parsePriorities(M)||PRIORITIES_DEFAULT;
  $("#pri").innerHTML=pr.map(([n,it],i)=>`<article class="pcard"><span class="pnum xw">${String(i+1).padStart(2,"0")}</span><h3 class="xw">${esc(n)}</h3><ul>${it.map(x=>`<li>${esc(x)}</li>`).join("")}</ul></article>`).join("");
  $$(".pin-words blockquote").forEach(bq=>{const walk=n=>{[...n.childNodes].forEach(c=>{if(c.nodeType===3){const f=document.createDocumentFragment();c.textContent.split(/(\s+)/).forEach(t=>{if(!t)return;if(/^\s+$/.test(t))f.appendChild(document.createTextNode(t));else{const sp=document.createElement("span");sp.className="w";sp.textContent=t;f.appendChild(sp)}});c.replaceWith(f)}else walk(c)})};walk(bq)});
  // Latest from USG: the homepage's Instagram block if there is one, otherwise its photo gallery
  const ig=M.querySelector(".sqs-block-instagram,.instagram-block,[class*='instagram-block'],[data-block-type='25']");const sec=$("#latest"),wall=$("#latestWall");
  const igPosts=ig?instagramPosts(ig):[];
  if(igPosts.length){latestLayout(sec,wall,igPosts)}
  else if(ig){wall.className="ig-host";wall.appendChild(ig);sec.hidden=false}
  else{const pics=[];const seen=new Set();M.querySelectorAll(".sqs-gallery img,.gallery-block img,.sqs-gallery-container img").forEach(im=>{const u=imgSrc(im);if(!u||seen.has(u))return;seen.add(u);let cap=(im.getAttribute("alt")||"").trim();const a=im.closest("a");if(a&&a.dataset.description){const t=document.createElement("div");t.innerHTML=a.dataset.description;cap=t.textContent.trim()||cap}pics.push({u,cap})});
    if(pics.length){wall.className="wall";wall.innerHTML=pics.map((p,i)=>`<button type="button" class="poster" data-lbu="${esc(sized(p.u,2000))}" data-caption="${esc(p.cap)}" style="--r:${[-2.2,1.6,-1,2.4,-1.8,1][i%6]}deg"><div class="paper"><span class="tape"></span><img src="${esc(sized(p.u,750))}" alt="${esc(p.cap.slice(0,140))}" loading="lazy"></div>${p.cap?`<p class="gcap">${esc(p.cap)}</p>`:""}</button>`).join("");sec.hidden=false}}
  const firstImg=[...M.querySelectorAll("img")].find(im=>!im.closest(".sqs-gallery,.gallery-block,.sqs-gallery-container,.sqs-block-instagram")&&imgSrc(im));
  if(firstImg){$("#missionPhoto").innerHTML=`<img src="${esc(sized(imgSrc(firstImg),2000))}" alt="The USG Senate">`;$("#missionPhoto").hidden=false}
  $("#cgridHome").innerHTML=cardsHTML();renderVideo();
  loadChairPhotos().then(()=>{if(Object.keys(CHAIRNAME).length){$("#cgridHome").innerHTML=cardsHTML();reveal($("#cgridHome"))}});
  /* fill the ticker and add the priorities' swipe dots now, so nothing above the mission grows later */
  {const t=$("#track");if(t&&!t.children.length){const h=["Frist 204 is open seven days a week","Tea, coffee, and snacks on us","Questions? usg@princeton.edu","Serve. Represent. Advocate."].map(x=>`<span>${esc(x)}</span>`).join("");t.innerHTML=h+h}}
  try{mobileFX()}catch(e){}
  const evs=$("#events");if(evs){evs.hidden=false;evs.classList.add("ev-loading")}
  EVENTS=await loadEvents();if(evs)evs.classList.remove("ev-loading");renderEvents();afterRender($("#v-home"));sizePins()}
async function pageEvents(M){band([["USG","/"],["Resources"]],"Events Calendar");
  const out=$("#innerOut");out.innerHTML=`<div class="sh"><h2 class="xw">What’s on</h2><div class="ev-tools"><div class="seg" role="group" aria-label="Event view"><button aria-pressed="true" data-view="wall">Posters</button><button aria-pressed="false" data-view="month">Calendar</button></div></div></div><div class="evOut"></div>`;
  out.querySelectorAll(".seg button").forEach(b=>b.onclick=()=>{evView=b.dataset.view;out.querySelectorAll(".seg button").forEach(x=>x.setAttribute("aria-pressed",x===b));renderEvents()});
  EVENTS=await loadEvents();if(!EVENTS.length){out.innerHTML="";out.appendChild(wrapProse(M));prep(M);afterRender(out);return}renderEvents()}
async function pageEvent(M){let it=null;try{it=(await sqJSON(PATH)).item}catch(e){}
  const e=normEvent(it);if(!e){band([["USG","/"],["Events","/events-calendar"]],document.title.split(/ [—|-] /)[0]);genericBody(M);return}
  band([["USG","/"],["Events","/events-calendar"]],e.title,{tag:`<p class="cm-tag">${esc(when(e))}</p>`});
  const out=$("#innerOut");out.innerHTML=`<div class="ev-page">${e.image?`<div class="ev-poster"><img src="${esc(sized(it.assetUrl,1500))}" alt="Poster for ${esc(e.title)}"></div>`:""}<div>
    <dl class="facts">${[["When",when(e)],["Where",e.location]].filter(x=>x[1]).map(([k,v])=>`<div><dt>${k}</dt><dd>${esc(v)}</dd></div>`).join("")}</dl>
    <div class="row" style="margin:22px 0 30px;display:flex;gap:10px;flex-wrap:wrap"><a class="btn o" href="${esc(gcal(e))}" target="_blank" rel="noopener">Add to Google Calendar</a><a class="btn alt" href="/events-calendar">All events</a></div>
    <div class="prose ev-body"></div></div></div>`;
  const b=out.querySelector(".ev-body");b.innerHTML=it.body||"";b.querySelectorAll("img").forEach(im=>{if(imgSrc(im)===it.assetUrl)im.remove()});prep(b);afterRender(out)}
function wrapProse(M){const d=document.createElement("div");d.className="prose sq-content";d.appendChild(M);return d}
function genericBody(M){const out=$("#innerOut");out.innerHTML="";out.appendChild(wrapProse(M));prep(M);booksLayout(M);
  if(/^\/(19|20)\d\d(classgovernment|-class-government|class)?$/.test(PATH))classOfficers(M);sectionGrid(M);afterRender(out)}
/* class pages, however they're written ("Role / Name" blocks, "Role: Name" lines, or just names), become:
   heading → class photo (if it's a real photo, not the USG logo) → a grid of officer cards */
function classOfficers(M){
  const heads=[...M.querySelectorAll("h1,h2,h3")];const h=heads.find(x=>/officers?|class council|class government/i.test(x.textContent));if(!h)return;
  const lvl=+h.tagName[1];const all=[...M.querySelectorAll("h1,h2,h3,h4,h5,h6,p,li,figure,.sqs-block-image,.image-block,hr,.sm-inpage")].filter(e=>!e.parentElement.closest("li,figure,.sm-inpage,.image-block"));
  const i0=all.indexOf(h);let end=all.length;for(let k=i0+1;k<all.length;k++){const e=all[k];if(e.tagName==="HR"||(/^H[1-3]$/.test(e.tagName)&&+e.tagName[1]<=lvl)){end=k;break}}
  const sect=all.slice(0,end);
  // the class photo: first real image in or just above the officers section; the USG logo stand-in is dropped
  const isLogo=img=>{const u=(imgSrc(img)||"")+" "+(img.getAttribute("alt")||"");if(/logo|usg[+_\- ]?(icon|seal|mark)|C299BJL8H6JV3NY6MNTV/i.test(u))return true;
    const d=(img.getAttribute("data-image-dimensions")||"").split("x").map(Number);return /\.png/i.test(u)&&d.length===2&&d[0]&&Math.abs(d[0]/d[1]-1)<.08};
  const imgs=sect.filter(e=>e.matches("figure,.sqs-block-image,.image-block")&&e.querySelector("img")&&!e.closest(".sm-inpage")).slice(-3);
  let photo=null;imgs.forEach(f=>{const im=f.querySelector("img");if(isLogo(im)){(f.closest(".sqs-block")||f).remove();return}if(!photo&&!(f.querySelector("figcaption")&&f.querySelector("figcaption").textContent.trim()))photo=im});
  // officer lines after the heading
  const people=[];const used=[];
  all.slice(i0+1,end).forEach(e=>{if(!/^(P|H4|H5|H6|H3|LI)$/.test(e.tagName)||e.closest(".sm-inpage,.docrow,.chip-list"))return;if(e.querySelector("a[href],img"))return;
    const t=e.cloneNode(true);t.querySelectorAll("br").forEach(b=>b.replaceWith("\n"));const lines=t.textContent.split("\n").map(x=>x.replace(/\u00a0/g," ").trim()).filter(Boolean);
    if(!lines.length||lines.join(" ").length>90||/[.!?]$/.test(lines[lines.length-1])&&lines.join(" ").split(" ").length>6)return;
    const fix=n=>/(^|\s)\p{Ll}/u.test(n)?tc(n):n;
    if(lines.length===1){const m=lines[0].match(/^(.{2,40}?)\s*(?::|\s[–—-]\s)\s*(.+)$/);if(m)people.push({role:m[1].trim(),name:fix(m[2].trim())});else if(lines[0].split(" ").length<=4)people.push({role:"",name:fix(lines[0])});else return}
    else if(lines.length===2)people.push({role:lines[0],name:fix(lines[1])});else return;
    used.push(e)});
  if(people.length<2)return;
  /* officers in order of office; President + Vice President featured on the top row */
  const RANK=[/^(class )?president\b/i,/^vice[\s-]?president|^vp\b/i,/treasurer/i,/secretary/i,/social/i,/chair|director|manager|coordinator|rep/i];
  const rank=r=>{if(!r)return RANK.length+1;const i=RANK.findIndex(x=>x.test(r.trim()));return i<0?RANK.length:i};
  people.forEach((p,i)=>{p.i=i;p.k=rank(p.role)});people.sort((a,b)=>a.k-b.k||a.i-b.i);
  const initials=n=>{const w=n.replace(/[’']/g,"").split(/\s+/).filter(Boolean);return((w[0]||"")[0]||"").toUpperCase()+(w.length>1?(w[w.length-1][0]||"").toUpperCase():"")};
  const card=(p,big)=>`<div class="off${big?" off-big":""}"><span class="off-av" aria-hidden="true">${esc(initials(p.name))}</span>${p.role?`<span class="role">${esc(p.role)}</span>`:""}<span class="name">${esc(p.name)}</span></div>`;
  const top=people.filter(p=>p.k<=1),rest=people.filter(p=>p.k>1);
  const grid=document.createElement("div");grid.className="officers";
  grid.innerHTML=(top.length?`<div class="off-row off-row-top">${top.map(p=>card(p,true)).join("")}</div>`:"")+(rest.length?`<div class="off-row">${rest.map(p=>card(p,false)).join("")}</div>`:"");
  const anchor=h.closest(".sqs-block")||h;anchor.after(grid);
  if(photo){const fig=document.createElement("figure");fig.className="class-photo";const im=document.createElement("img");im.src=sized(imgSrc(photo),2000);im.alt=photo.getAttribute("alt")||"Class officers";fig.appendChild(im);
    const pb=photo.closest(".sqs-block")||photo.closest("figure")||photo;pb.remove();anchor.after(fig)}
  used.forEach(e=>{const b=e.closest(".sqs-block");e.remove();if(b&&!b.textContent.trim()&&!b.querySelector("img,iframe,form"))b.remove()});
  M.querySelectorAll(".sqs-col,[class*='sqs-col-'],.sqs-row").forEach(c=>{if(!c.textContent.trim()&&!c.querySelector("img,iframe,form,video,.flip,.officers,.class-photo"))c.remove()})}
/* split a page into its H2 sections and lay them out two-up on wide screens */
/* a run of whole-line document links (one per paragraph) becomes one tidy list that can sit in two columns */
function docLists(M){const isDoc=el=>el&&/^(P|LI)$/.test(el.tagName)&&el.querySelector(":scope>a.file.solo, :scope>*>a.file.solo")&&el.textContent.trim()===el.querySelector("a.file.solo").textContent.trim();
  M.querySelectorAll("p,li").forEach(el=>{if(el.closest(".doc-list,.book,.books")||!isDoc(el)||isDoc(el.previousElementSibling))return;
    const run=[el];let n=el.nextElementSibling;while(n&&(isDoc(n)||(n.tagName==="P"&&!n.textContent.trim()&&!n.querySelector("img,iframe")&&isDoc(n.nextElementSibling)))){if(isDoc(n))run.push(n);n=n.nextElementSibling}
    if(run.length<4)return;const box=document.createElement("div");box.className="doc-list";el.before(box);run.forEach(r=>box.appendChild(r.querySelector("a.file.solo")));run.forEach(r=>r.remove())})}
function sectionGrid(M){docLists(M);const pick=".sqs-block,.sq-cardgrid,.books,.sm-inpage,.officers,.class-photo";
  let units=[...M.querySelectorAll(pick)].filter(u=>{let p=u.parentElement;while(p&&p!==M){if(p.matches(pick))return false;p=p.parentElement}return true});
  if(!units.length)return;
  // a text block holding several sections is split at each H2
  const split=[];units.forEach(u=>{let inner=null;if(u.matches(".sqs-block")){const h=u.querySelector("h2");inner=h?h.parentElement:(u.querySelector(".sqs-html-content")||u.querySelector(":scope>.sqs-block-content"));if(inner&&inner.closest("li,blockquote,table"))inner=null}const kids=inner?[...inner.children]:[];
    if(!inner||kids.filter(k=>k.tagName==="H2").length<1||(kids[0]&&kids[0].tagName==="H2"&&kids.filter(k=>k.tagName==="H2").length===1)||u.querySelector("form,iframe,.flip")){split.push(u);return}
    let cur=null;const parts=[];kids.forEach(k=>{if(k.tagName==="H2"||!cur){cur=document.createElement("div");cur.className="sqs-block html-block sq-chunk";const c=document.createElement("div");c.className="sqs-block-content";cur.appendChild(c);parts.push(cur)}cur.firstChild.appendChild(k)});
    u.replaceWith(...parts);split.push(...parts)});
  units=split;
  const startsH2=u=>{const f=u.querySelector("h1,h2,h3,h4,p,ul,ol,img,iframe,hr,figure,.flip,.sm-grid");let el=f;if(el&&el.tagName==="HR"){const n=u.querySelector("h2");return!!n}return!!(el&&el.tagName==="H2")};
  const groups=[];let cur=null;units.forEach(u=>{if(!cur||startsH2(u)){cur={units:[],intro:!groups.length&&!startsH2(u)};groups.push(cur)}cur.units.push(u)});
  if(groups.filter(g=>!g.intro).length<2)return;
  const grid=document.createElement("div");grid.className="sq-sections";let narrow=0;
  groups.forEach(g=>{const sec=document.createElement("section");sec.className="sq-sec"+(g.intro?" sq-intro":"");g.units.forEach(u=>sec.appendChild(u));
    const big=sec.querySelector(".flip,.books,.wall,iframe,.sm-grid,.sq-cardgrid,form,table,video,.chip-list,.officers,.class-photo")||sec.querySelectorAll(".docrow,a.file.solo").length>3||sec.textContent.length>4000;
    if(big)sec.classList.add("wide");grid.appendChild(sec)});
  /* half-width sections pair up; one left on its own goes full width so no gap opens beside it */
  let run=[];const close=()=>{if(run.length%2===1)run[run.length-1].classList.add("wide");narrow+=run.length-(run.length%2);run=[]};
  [...grid.children].forEach(sec=>{if(sec.classList.contains("wide")||sec.classList.contains("sq-intro"))close();else run.push(sec)});close();
  if(narrow>=2)grid.classList.add("two");
  const host=M.querySelector(".sqs-layout")||M;host.innerHTML="";host.appendChild(grid)}
/* Scanned documents (flipbooks): give each its heading and download button, full width, instead of squeezing them into Squarespace columns */
function booksLayout(M){const flips=[...M.querySelectorAll(".usg-done > .flip")];if(!flips.length)return;
  const heads=[...M.querySelectorAll("h1,h2,h3")].filter(h=>!h.closest(".books"));
  const links=[...M.querySelectorAll("a.file")];
  const books=document.createElement("div");books.className="books";
  /* a general title naming several documents ("USG Constitution and Amendments") is the page heading, not one book's */
  const generic=h=>{const t=h.textContent.toLowerCase();const kinds=["constitution","amendment","charter","bylaw","rules","documents"].filter(k=>t.includes(k)).length;return kinds>=2&&/\band\b|&|,/.test(t)||/governing documents|documents and charters/.test(t)};
  const pickHead=(i,f)=>{const docHeads=heads.filter(h=>!h._used&&!generic(h)&&/constitution|amendment|charter|bylaw|rules/i.test(h.textContent));
    const before=heads.filter(h=>!h._used&&!generic(h)&&h.compareDocumentPosition(f)&Node.DOCUMENT_POSITION_FOLLOWING);
    return docHeads[0]||before[before.length-1]||null};
  const fb0=flips[0].parentElement;let anchorRow=null;{let r=fb0.closest(".sqs-row");while(r&&r.parentElement&&r.parentElement.closest(".sqs-row"))r=r.parentElement.closest(".sqs-row");anchorRow=r||fb0.closest(".sqs-block")}
  /* Squarespace often stacks all the headings first and all the books after, so headings can't be trusted to pair by position.
     Each book's own download link (same order as the books) names it; headings are only a fallback. */
  /* the books' own links: ones labelled "Download…", else the first file links that come right after the last book */
  let dls=links.filter(a=>/^\s*download\b/i.test(a.textContent)&&!a.closest(".books"));
  if(dls.length!==flips.length){const last=flips[flips.length-1];dls=links.filter(a=>!a.closest(".books")&&(last.compareDocumentPosition(a)&Node.DOCUMENT_POSITION_FOLLOWING)).slice(0,flips.length)}
  const pageHead=heads.find(h=>generic(h));
  flips.forEach((f,i)=>{let link=dls.length===flips.length?dls[i]:null;
    let title=link?link.textContent.replace(/^\s*download\s+/i,"").replace(/\s*\((pdf|doc|docx)\)\s*$/i,"").trim():"";
    let h=null;if(!title){h=pickHead(i,f);title=h?h.textContent.trim():"Document "+(i+1)}
    else{const tw=title.toLowerCase();h=heads.find(x=>!x._used&&!generic(x)&&x.textContent.trim().toLowerCase().replace(/^the\s+/,"")===tw.replace(/^the\s+/,""))||heads.find(x=>!x._used&&!generic(x)&&(/amend/i.test(x.textContent)===/amend/i.test(title))&&/constitution|amendment|charter|bylaw|rules/i.test(x.textContent))}
    if(h){h._used=true;if(link)title=h.textContent.trim()}f.dataset.title=title;
    if(link)link._used=true;
    const sec=document.createElement("section");sec.className="book";sec.innerHTML=`<h2>${esc(title)}</h2>`;
    const box=f.parentElement;sec.appendChild(f);if(link){const l=link.cloneNode(true);l.classList.add("solo");sec.appendChild(l);const lp=link.closest("p,li");(lp&&lp.textContent.trim()===link.textContent.trim()?lp:link).remove()}
    books.appendChild(sec);if(h){const blk=h.closest(".sqs-block")||h;if(blk.textContent.trim()===h.textContent.trim())blk.remove();else h.remove()}
    const gb=box.closest(".sqs-block")||box;gb.remove()});
  if(pageHead&&pageHead.isConnected){const hd=document.createElement("h2");hd.className="books-head";hd.textContent=pageHead.textContent.trim();books.prepend(hd);const blk=pageHead.closest(".sqs-block")||pageHead;if(blk.textContent.trim()===pageHead.textContent.trim())blk.remove();else pageHead.remove()}
  if(flips.length>1)books.classList.add("books-2");
  if(anchorRow&&anchorRow.isConnected)anchorRow.parentNode.insertBefore(books,anchorRow);else{const fb=M.querySelector(".sqs-layout")||M;fb.insertBefore(books,fb.firstChild)}
  // tidy empty Squarespace columns/rows left behind
  M.querySelectorAll(".sqs-col,[class*='sqs-col-'],.sqs-row,.row").forEach(c=>{if(!c.textContent.trim()&&!c.querySelector("img,iframe,form,video,.flip"))c.remove()});
  // a short intro paragraph that was above the documents stays above them
}
function pageContact(M){band([["USG","/"],["Get involved"]],"Contact Us");const out=$("#innerOut");
  out.innerHTML=`<div class="ct"><div class="ct-main"></div><aside class="ct-side"><div class="ct-card"><h2>Our office</h2><p>Frist Campus Center, Room 204<br>Princeton University</p><ul class="ct-hours"><li><span>Sun – Thu</span><span>4:30 – 7:30 PM</span></li><li><span>Fri – Sat</span><span>2:00 – 5:00 PM</span></li></ul><p class="ct-snack">Tea, coffee, and snacks on us.</p></div>
    <div class="ct-card"><h2>Email</h2><p><a href="mailto:usg@princeton.edu">usg@princeton.edu</a></p><h2>Instagram</h2><p><a href="https://www.instagram.com/princeton_usg/" target="_blank" rel="noopener">@princeton_usg</a></p></div></aside></div>`;
  out.querySelector(".ct-main").appendChild(wrapProse(M));prep(M);afterRender(out)}
async function pageCommittees(M){band([["USG","/"],["Get involved"]],"Committees");
  CBODY=committeeSections(M);await loadChairPhotos();
  const show=()=>{const h=location.hash.slice(1);clearTheme();if(h.startsWith("c-")&&viewCommittee(h.slice(2)))return;
    band([["USG","/"],["Get involved"]],"Committees");const out=$("#innerOut");out.innerHTML="";
    /* main page: the intro + bubbles only; each committee's text lives on its own page */
    if(!M._trimmed){(CBODY._used||[]).forEach(e=>{const blk=e.closest(".sqs-block");e.remove();if(blk&&!blk.textContent.trim()&&!blk.querySelector("img,iframe,form"))blk.remove()});
      M.querySelectorAll("hr").forEach(h=>{const n=h.nextElementSibling;if(!n||/^HR$/.test(n.tagName))h.remove()});M._trimmed=true}
    indexLayout(out,M,COMMITTEES.map(c=>({href:"/committees#c-"+c.slug,name:c.name,theme:THEMES[c.slug]})),cardsHTML(),"Jump to a committee","The seven USG committees aid the USG Senate in serving the Princeton undergraduate student body.");afterRender(out)};
  addEventListener("hashchange",show);show()}

/* ---------- boot ---------- */
function unhide(){document.documentElement.classList.remove("usg-loading")}
function ensureFont(){const href="https://fonts.googleapis.com/css2?family=Archivo:ital,wdth,wght@0,62..125,100..900;1,62..125,100..900&display=swap";
  if(![...document.querySelectorAll("link[rel=stylesheet]")].some(l=>l.href.includes("family=Archivo"))){const l=document.createElement("link");l.rel="stylesheet";l.href=href;document.head.appendChild(l)}}
/* stray text OUTSIDE the new layout (e.g. a page's own code injection missing its <script> tags gets printed at the top of the page) */
function sweepStray(){const root=document.getElementById("usg-root");if(!document.body)return;
  const keep=n=>{const p=n.parentElement;return !p||(root&&root.contains(p))||p.closest("script,style,noscript,template,textarea,.usg-cookie,[contenteditable],.sqs-edit-mode,iframe")};
  const w=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);const kill=[];
  while(w.nextNode()){const n=w.currentNode;const t=n.nodeValue.trim();if(!t||keep(n))continue;const p=n.parentElement;
    /* loose text directly in the page, or anything that reads like code: remove it */
    if(p===document.body||p===document.documentElement||/[{}();$]/.test(t)&&(t.match(/[{}();$=]/g)||[]).length>=3)kill.push(n)}
  kill.forEach(n=>n.remove())}
async function boot(){sweepStray();
  if(MIRROR){let t=0;new MutationObserver(()=>{clearTimeout(t);t=setTimeout(()=>mirrorLinks(document.getElementById("usg-root")),60)}).observe(document.body,{childList:true,subtree:true})}try{new MutationObserver(()=>sweepStray()).observe(document.body,{childList:true});}catch(e){}

  if(matchMedia("(hover:none)").matches||matchMedia("(pointer:coarse)").matches&&!matchMedia("(hover:hover)").matches)document.documentElement.classList.add("touch");
  if(window.self!==window.top||/[?&]skin=off/.test(location.search)||document.querySelector("body.sqs-edit-mode,.sqs-edit-mode-active")){unhide();return}
  const M=document.querySelector('[data-content-field="main-content"]')||document.querySelector("main .sqs-layout")||document.querySelector("main")||document.querySelector("#content");
  if(!M){unhide();return}
  /* note Squarespace's banner/background video now, before anything gets tidied away */
  SQV=sqsVideo();

  ensureFont();const root=document.createElement("div");root.id="usg-root";root.className="usg-r";root.innerHTML=SHELL;document.body.appendChild(root);
  {const m=root.querySelector("main");if(m){m.id=m.id||"main";m.tabIndex=-1}const sk=document.createElement("a");sk.className="skip-link";sk.href="#"+(m?m.id:"usg-root");sk.textContent="Skip to content";root.prepend(sk);
   sk.addEventListener("click",e=>{e.preventDefault();const t=document.getElementById(sk.getAttribute("href").slice(1));if(t){t.focus({preventScroll:false});t.scrollIntoView()}})}
  document.documentElement.classList.add("usg-skin");wireShell();
  const title=(document.querySelector('meta[property="og:title"]')||{}).content||document.title;
  const t=String(title).split(/ [—|–-] /)[0].replace(/ — Princeton USG$/,"").trim();
  try{
    if(PATH==="/"||PATH==="/home")await pageHome(M);
    else if(/[?&]preview=home/.test(location.search)){
      /* preview the homepage design on any page, using the real homepage's content */
      let H=document.createElement("div");try{const j=await sqJSON("/");H.innerHTML=j.mainContent||((j.collection||{}).mainContent)||""}catch(e){}
      await pageHome(H)}
    else{$("#v-home").hidden=true;$("#v-inner").hidden=false;
      if(PATH==="/senate-members"||PATH==="/senatemembers"){if(!viewSenate(M)){band([["USG","/"],["Senate"]],t);genericBody(M)}}
      else if(PATH==="/committees")await pageCommittees(M);
      else if(PATH==="/workinggroups"||PATH==="/working-groups")await pageGroups(M);
      else if(PATH==="/events-calendar"||PATH==="/resources")await pageEvents(M);
      else if(PATH.startsWith("/events-calendar/"))await pageEvent(M);
      else if(PATH==="/contactus")pageContact(M);
      else{const sec=NAV.find(([n,ls])=>ls.some(([,h])=>h.toLowerCase()===PATH));band([["USG","/"],...(sec?[[sec[0]]]:[])],t||"Princeton USG");genericBody(M)}}
  }catch(err){console.error("USG skin:",err)}
  unhide();fitWord();document.fonts&&document.fonts.ready.then(fitWord);styleCookie();setTimeout(styleCookie,1500);clearTop();setTimeout(clearTop,800);addEventListener("load",clearTop);checkNoScroll();mobileFX();requestTick()}
/* bubble lettering is sized to fit its own circle once the real fonts have loaded */
function fitBubbles(){$$(".orbit-hub").forEach(h=>{const b=h.querySelector("b");if(!b)return;const D=h.clientWidth;if(!D)return;b.style.removeProperty("font-size");b.style.display="block";b.style.maxWidth=(D*.8)+"px";b.style.margin="0 auto";
    let fs=parseFloat(getComputedStyle(b).fontSize),n=0;while((b.scrollWidth>b.clientWidth+1||b.getBoundingClientRect().height>D*.3)&&fs>8&&n++<60){fs*=.94;b.style.setProperty("font-size",fs+"px","important")}});
  $$(".orbit .bub").forEach(a=>{const inn=a.querySelector(".bub-in");if(!inn)return;const D=inn.clientWidth;if(!D)return;
  const parts=[["b",.66,.34],["small",.62,.26]];
  parts.forEach(([sel,wf,hf])=>{const el=[...inn.children].find(x=>x.tagName.toLowerCase()===sel);if(!el)return;
    el.style.removeProperty("font-size");el.style.display="block";el.style.maxWidth=(D*wf)+"px";el.style.marginLeft="auto";el.style.marginRight="auto";
    let fs=parseFloat(getComputedStyle(el).fontSize),n=0;
    const big=()=>el.scrollWidth>el.clientWidth+1||el.getBoundingClientRect().height>D*hf;
    while(big()&&fs>8&&n++<60){fs*=.94;el.style.setProperty("font-size",fs+"px","important")}})})}
if(document.fonts){document.fonts.ready.then(fitBubbles);document.fonts.addEventListener&&document.fonts.addEventListener("loadingdone",()=>setTimeout(fitBubbles,30))}
let _fb;addEventListener("resize",()=>{clearTimeout(_fb);_fb=setTimeout(fitBubbles,160)});
{const __ar=afterRender;afterRender=function(r){__ar(r);fitBubbles();setTimeout(fitBubbles,400);try{a11y(r||document.getElementById("usg-root"));mirrorLinks(document.getElementById("usg-root"))}catch(e){}}}
/* accessibility: real alt text (never a filename), labelled form fields, keyboard-reachable scroll areas, decorative bits hidden from screen readers */
const FILEISH=/\.(jpe?g|png|gif|webp|heic|svg)$|^(img|dsc|image|photo|screenshot|untitled)[\s_-]*\d|^\d{6,}|^[\w-]{20,}$/i;
function altFor(img){const fig=img.closest("figure,.sm,.pc,.poster,.ig-tile,.book,.chair-card,.chair,.officer,.cm-chair,.thumb,.slide");
  const book=img.closest(".book");if(book){const t=book.querySelector("h2");const imgs=[...book.querySelectorAll("img")];return (t?t.textContent.trim():"Document")+", page "+(imgs.indexOf(img)+1)}
  const nm=fig&&fig.querySelector(".sm-name,.name,.pc-name,b,strong");if(nm&&nm.textContent.trim().length<60&&fig.matches(".sm,.pc,.chair-card,.chair,.officer,.cm-chair,figure"))return "Photo of "+nm.textContent.trim();
  const cap=fig&&fig.querySelector("figcaption,.gcap,.ig-cap,.image-caption,h3,h4");if(cap&&cap.textContent.trim())return cap.textContent.trim().slice(0,140);
  const t=(img.getAttribute("title")||"").trim();if(t&&!FILEISH.test(t))return t;return ""}
function a11y(R){if(!R)return;
  R.querySelectorAll("img").forEach(img=>{if(!(img.getAttribute("src")||img.getAttribute("data-src")||img.currentSrc)){img.setAttribute("alt","");return}const a=(img.getAttribute("alt")||"").trim();if(img.hasAttribute("alt")&&a&&!FILEISH.test(a))return;img.setAttribute("alt",altFor(img))});
  R.querySelectorAll("svg:not([role]):not([aria-label])").forEach(s=>{if(!s.querySelector("title"))s.setAttribute("aria-hidden","true")});
  R.querySelectorAll("input:not([type=hidden]):not([type=submit]):not([type=button]),textarea,select").forEach(f=>{
    if(f.getAttribute("aria-label")||f.getAttribute("aria-labelledby")||f.closest("label")||(f.id&&R.querySelector(`label[for="${CSS.escape(f.id)}"]`)))return;
    const fld=f.closest(".form-item,.field,fieldset,.field-list > *");const lab=fld&&fld.querySelector(".title,legend,.field-label,.caption,label");
    const name=(lab&&lab.textContent.replace(/\*|\(required\)/gi,"").trim())||f.getAttribute("placeholder")||(f.name||"").replace(/[-_]/g," ").trim()||"Search";f.setAttribute("aria-label",name)});
  R.querySelectorAll("#pri,.ph-track,.wall,.ig-grid2,.sq-sections .scroll-x,[data-swipe]").forEach(el=>{if(el.scrollWidth>el.clientWidth+4&&!el.querySelector("a,button,[tabindex]")){el.tabIndex=0;if(!el.getAttribute("role"))el.setAttribute("role","region");if(!el.getAttribute("aria-label"))el.setAttribute("aria-label",(el.closest("section")?.querySelector("h2")?.textContent||"Scrollable list").trim())}});
  R.querySelectorAll(".url-link").forEach(a=>{a.style.removeProperty("letter-spacing")});
  R.querySelectorAll("iframe:not([title]),iframe[title='']").forEach(f=>f.setAttribute("title",/youtube|vimeo/.test(f.src)?"Video":"Embedded content"))}
/* the giant TIGERS in the footer always fits its box exactly */
function fitWord(){$$(".bigword").forEach(el=>{el.style.fontSize="";const cs=parseFloat(getComputedStyle(el).fontSize);el.style.whiteSpace="nowrap";
  const box=el.clientWidth;const span=el._s||(el._s=(()=>{const sp=document.createElement("span");sp.style.display="inline-block";while(el.firstChild)sp.appendChild(el.firstChild);el.appendChild(sp);return sp})());
  const w=span.getBoundingClientRect().width;if(w>box&&w>0)el.style.fontSize=(cs*box/w*0.98)+"px"})}
let _fw;addEventListener("resize",()=>{clearTimeout(_fw);_fw=setTimeout(fitWord,150)});
/* Squarespace's cookie notice: keep it working, dress it in the new style. It can appear after load, so watch for it. */
function styleCookie(){const root=$("#usg-root");
  [...document.querySelectorAll('[class*="cookie"],[id*="cookie"]')].filter(el=>!(root&&root.contains(el))&&!el.closest(".usg-cookie")&&!/^(BUTTON|A|INPUT|P|SPAN)$/.test(el.tagName)).forEach(el=>{if(el.closest(".usg-cookie"))return;
    const cs=getComputedStyle(el),bg=cs.backgroundColor,r=el.getBoundingClientRect();
    const painted=bg&&bg!=="transparent"&&!/rgba\(\s*0,\s*0,\s*0,\s*0\s*\)/.test(bg);
    if(painted&&r.width>0&&r.height>0&&r.height<innerHeight*0.6){el.classList.add("usg-cookie");
      el.querySelectorAll("button,a,[role=button],input[type=button],input[type=submit]").forEach(b=>b.classList.add("usg-cookie-btn"))}})}
new MutationObserver(()=>styleCookie()).observe(document.documentElement,{childList:true,subtree:true});
/* Anything the template still draws above the new header (a bar, a border, an empty strip): find it and remove it. */
function clearTop(){const root=$("#usg-root");if(!root||scrollY>2)return;const found=[];
  [0.02,0.25,0.5,0.75,0.98].forEach(fx=>[2,20].forEach(y=>{(document.elementsFromPoint(innerWidth*fx,y)||[]).forEach(el=>{
    if(el===document.documentElement||el===document.body||root.contains(el)||found.includes(el))return;const top=el.closest("body>*")||el;
    if(/cookie|lightbox|modal/i.test((top.className||"")+(top.id||"")))return;top.style.setProperty("display","none","important");found.push(el)})}));
  const off=root.getBoundingClientRect().top+scrollY;
  if(off>1){root.style.setProperty("margin-top",(-off)+"px","important");console.info("USG skin: closed a "+Math.round(off)+"px gap above the header")}
  if(found.length)console.info("USG skin: hid template elements at the top of the page",found)}
if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",boot);else boot();
